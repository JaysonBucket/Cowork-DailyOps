---
name: daily-ops-ext
version: 2.1.0
description: |
  Personal daily-operations system for customer-facing roles (account managers, consultants,
  solution architects, project leads, customer success). Captures tasks, customers, stakeholders,
  projects, hours, and highlights in one structured hub. Connects tasks to people → calendar
  and recommends pulling work forward before shared meetings in the morning briefing.
  Maintains customer stakeholders automatically from mail/Teams/meetings. Filters out mass
  mails and large group chats. Tracks vacation balance and surfaces alerts when an externally
  booked vacation is not yet officially submitted. Tracks personal goals (cadence, time-budget,
  streak, anti-goal) against the calendar with Soll/Ist comparison and slot suggestions.
  Supports an additive Outlook-category intake path: tag a mail or event with `DOPS-Intake`
  (auto-classify) or a typed variant (`DOPS-Intake-Task/Customer/Highlight/Goal`) and the
  next drain or sync folds it in and removes the category.

  Day cycle: 07:00 morning briefing as a mail with capture codes and mailto links per task
  and per meeting. During the day the user sends status updates and meeting notes by mail
  to themself (a mail rule matches "DOPS-" in the subject). 10:00/12:00/14:00 capture-drain
  runs fold captures into tasks.json between full syncs (silent unless attention is needed).
  15:30 afternoon sync reads all captures, updates tasks/customer JSONs, mirrors to OneDrive,
  writes the daily snapshot, sends the sync report.

  Primary triggers (DOPS-prefix short commands — do NOT collide with built-in daily-briefing):
  "DOPS start", "DOPS morning", "DOPS briefing" (morning briefing); "DOPS sync", "DOPS close"
  (afternoon sync); "DOPS drain" (capture-drain manual run); "DOPS check" (status without
  mail); "DOPS review" (review preparation); "DOPS care" (ad-hoc customer stakeholder
  maintenance); "DOPS urlaub" (vacation balance + open submissions).

  Secondary triggers (distinctive natural phrases): "Daily-Ops briefing", "Daily-Ops sync",
  "pull forward before meeting", "stakeholders at customer X", "review preparation",
  "highlights log", "who is at which customer next week", "vacation balance",
  "vacation submissions open".

  Do NOT use for: generic calendar overview without customer context (use built-in
  daily-briefing/calendar-management); single-meeting recaps (use meeting-intel); ad-hoc
  mail triage without customer context. Generic phrases like "morning briefing",
  "daily overview" are intentionally NOT triggered any more (collision risk with built-in
  daily-briefing) — use the explicit "DOPS" prefix.
---

# Daily-Ops Ext Skill v2.1.0

> **Generic variant** without company-specific terminology. Functionally equivalent to the internal `daily-ops-ms` variant (same version state v2.1.0) — but portable across industries and companies.

> Current version: **2.1.0** — see [CHANGELOG.md](CHANGELOG.md) for changes. **2.1.0 is additive** on top of 2.0.0 — adds personal goals tracking and Outlook-category intake. No data migration needed; goals.json is created on first morning briefing if absent. See SETUP.md for the new Outlook categories.

A personal operations system for roles that manage many customers, projects, and stakeholders in parallel. A template for import — all data generic, you populate it with your own world.

## What it solves

- **Tasks without context loss** — every task captures source (mail/Teams/meeting) AND the people involved
- **Pull forward before meeting** — if an open task touches people you have an upcoming meeting with, Cowork suggests handling it before that meeting
- **Customer stakeholders grow automatically** — new contacts from mails/Teams land in the hub + per-customer JSON, with gap markers for role and decision-maker level
- **Notes + Chronicle on every record** *(NEW in 2.0)* — every record (customer, stakeholder, project, partner, task, watchlist item, holiday, vacation entry, highlight, customer file) carries a `notes` field (free text, replace/append/clear) and a `chronicle` array (timestamped history with optional `event_id` cross-references). Stakeholder contact events log automatically to chronicle with the linked calendar event.
- **Review preparation** — highlights log, numbers tracker, review cycles in one central collection
- **Important personal dates** — birthdays, anniversaries, school holidays for your region
- **Bulk filter** — mass mails, newsletters, and large group chats are recognized, summarized as key points in the briefing, and auto-archived
- **Day cycle with mail capture** — 07:00 briefing mail with clickable capture links, you send updates by mail throughout the day, 15:30 Cowork folds everything in
- **Work/personal separation** — dedicated area filter, P-MMDD-NN codes for personal tasks, separate weekend briefing for personal-only items (Sat/Sun 07:00). In the Mon–Fri briefing, personal meetings appear compactly at the bottom; the top-3 stays work-only.
- **Security filter for captures** — the afternoon sync and capture drain only process DOPS mails from trusted senders (your own address, personal addresses, optional safe-senders list). Foreign captures are moved to `_rejected/` and flagged — no risk of externally injected tasks/stakeholders.
- **Capture drain** — three lightweight mid-day runs (10:00/12:00/14:00) fold new captures into `tasks.json` between morning briefing and afternoon sync. Silent unless something needs your attention.
- **Vacation tracking** — `urlaub` block in `wichtige-daten.json` with year-by-year balance (entitlement + carryover − used) and entry list. Status `geplant` = booked externally but not yet submitted → escalating alarm cadence (60d → 30d → 14d → P1). Carryover deadline alerts before the carryover deadline. Year rollover routine on the first weekday of each new year. Event-driven recalculation via `stale` flag *(NEW in 2.0)*.
- **Personal goals tracking** *(NEW in 2.1)* — `goals.json` with four goal types: `kadenz` (e.g. "3× sport per week"), `zeitbudget` (e.g. "4h focus per week"), `streak` (e.g. "read every day"), and `anti_goal` (e.g. "no more than 25 meetings per week"). Each goal matches calendar events by category or title keyword over a configurable `fenster` (rolling-7d / calendar-week / rolling-30d / calendar-month / daily). The morning briefing computes Soll/Ist per goal, surfaces unmet goals with a slot suggestion (no auto-create — user manually books the suggested slot in Outlook), and escalates anti-goal warnings/breaches. Manual hits can be logged via `DOPS-NEW Goal-Done <goal_id> <YYYY-MM-DD>` capture mail.
- **Outlook-category intake** *(NEW in 2.1)* — additive intake channel alongside the DOPS-mailto pipeline. Tag any Outlook mail or calendar event with a category and the next capture-drain or afternoon sync folds it in, then swaps the category to `DOPS-Intake-Done` (so nothing gets re-processed). Categories: `DOPS-Intake` (auto-classify based on sender/content/event) plus four typed override variants `DOPS-Intake-Task` / `-Customer` / `-Highlight` / `-Goal`. TYPED overrides AUTO if both are present. Same trusted-sender security filter as the mailto pipeline.
- **OneDrive mirror** *(NEW in 2.0)* — every JSON is mirrored to a personal OneDrive folder `daily-ops-readonly/` after the morning briefing, weekend briefing, and afternoon sync. Hash-based diff so only changed files are pushed. Read-access from mobile/web/manager — write stays in the skill.
- **Daily snapshots** *(NEW in 2.0)* — at 15:30 the afternoon sync copies the 10 living JSONs to `data/_snapshots/YYYY-MM-DD/`. Briefings, customer JSONs, and meeting-notes are date-keyed and self-historical, so they need no extra snapshot. ~250 KB per day, ~60 MB after a full year.

## File structure (v2.0)

```
data/
├── _meta.json                  # Schema/skill version, hashes per file, mirror/snapshot timestamps
├── customers.json
├── stakeholders-internal.json
├── stakeholders-customer.json
├── partners.json
├── projects.json
├── hours-log.json
├── watchlist.json
├── tasks.json                  # Inbox/active/blocked/done in one file (status field)
├── wichtige-daten.json         # personen_anlaesse + ferien_frei + urlaub (bilanz, config, eintraege)
├── highlights.json             # highlights + review_cycles + numbers_tracker
├── goals.json                  # personal goals (kadenz / zeitbudget / streak / anti_goal) — NEW in 2.1
├── Bulk-Sources.json           # sources + heuristics + allowlist
├── Kunden/
│   └── _TEMPLATE.json          # one JSON per customer (content_md + structured fields)
├── Meeting-Notes/              # YYYY-MM-DD-<CODE>.json per meeting (afternoon sync)
├── Briefings/                  # YYYY-MM-DD-morning.json | -afternoon.json | -weekend.json daily
├── _snapshots/                 # YYYY-MM-DD/ — daily folder copy of the 10 living JSONs
└── .drain-state.json           # capture-drain rolling state (last_run, processed count)
```

## Day cycle

```
  07:00 ────► 10/12/14 ────► During the day ────► 15:30
  Morning     Capture drain  Mail capture         Afternoon sync
  briefing    (silent unless DOPS- subject        + sync report mail
  + codes     attention)     → mail rule          + tasks/customers update
  + mailto    → fold into    → DOPS-Capture       + meeting-notes archival
  + mirror →  tasks.json                          + mirror → OneDrive
  OneDrive                                        + daily snapshot
```

**Capture-code schema:**
- `T-MMDD-NN` — work task code (sequential per day), stable across multiple days
- `P-MMDD-NN` — personal task code (separate sequence per day)
- `M-MMDD-XX` — meeting code (XX = short tag from the meeting title)
- `NEW` — ad-hoc task

**Mail subject format** for captures:
```
DOPS-T-0504-01 Contract renewal Customer X     → task update
DOPS-M-0504-PR Project Review Sync             → meeting note
DOPS-NEW Follow-up order ACME GmbH             → ad-hoc task
DOPS-NEW Urlaub-Recalc                         → trigger vacation recalculation (NEW in 2.0)
DOPS-NEW Mirror-Now                            → trigger interim OneDrive mirror (NEW in 2.0)
DOPS-NEW Goal-Done goal_sport 2026-05-04       → log a manual goal hit (NEW in 2.1)
```

A mail rule (Outlook/Gmail/etc.) matches `Subject contains DOPS-` → moves to `DOPS-Capture`.

**Mail body format** (pre-filled by the mailto link):

For tasks:
```
Status: [done | progress | paused | reschedule]

Note:

---
Context: <generated from the briefing — do not delete>
```

For meetings:
```
Notes:

New stakeholders: (Name <Mail>, Role)
Follow-up tasks:

---
Context: <generated from the briefing>
```

## Notes + Chronicle operations vocabulary (NEW in 2.0)

Every record has a `notes` field (single string) and a `chronicle` array (timestamped entries with optional `event_id`/`event_subject` for cross-reference to calendar). Operations available across the briefing/sync logic:

- `note_replace(record_id, text)` — overwrite the notes field
- `note_append(record_id, text)` — append `\n— DD.MM.: <text>` to existing notes
- `note_clear(record_id)` — set notes to `""`
- `chronicle_log(record_id, entry, topic?, event_id?, event_subject?, outcome?, follow_up_task_ids?)` — append a timestamped entry
- `chronicle_edit(record_id, ts, fields)` — edit one chronicle entry by timestamp (rare; use only on user request)
- `chronicle_link(record_id, ts, event_id, event_subject)` — backfill an event_id on an existing chronicle entry

Use `chronicle_log` liberally on stakeholder contact events; sparsely on customers/projects (only material status changes).

## Setup

1. **Import the skill** — create the skill directory according to your Cowork environment's conventions (see SETUP.md)
2. **Initial population** — customers, internal stakeholders, watchlist, important dates, review cycles. The shipped JSONs contain example rows you replace with your own.
3. **One JSON file per customer** in `data/Kunden/` (use `_TEMPLATE.json` as scaffold)
4. **Set up the mail rule** for `DOPS-` capture (see SETUP.md)
5. **OneDrive mirror folder** `daily-ops-readonly/` in your personal OneDrive — auto-created on first run
6. **Four scheduled prompts**:
   - Mon–Fri 07:00 — morning briefing (`scheduled-prompts/morning-briefing.md`)
   - Mon–Fri 10:00 / 12:00 / 14:00 — capture drain (`scheduled-prompts/capture-drain.md`)
   - Mon–Fri 15:30 — afternoon sync (`scheduled-prompts/afternoon-sync.md`)
   - Sat/Sun 07:00 — weekend briefing (`scheduled-prompts/weekend-briefing.md`)

In all prompts, replace `<SKILL_PATH>`, `<YOUR_MAIL>` and `<INTERNAL_DOMAIN>` once. For the personal filter additionally fill in `<PERSONAL_MAIL_1..3>` and `<FAMILY_NAMES>`. For the security filter optionally fill in `<SAFE_SENDERS>` with additional trusted senders.

## When to use this skill

**Command cheatsheet (DOPS prefix — recommended, does not collide with built-in daily-briefing):**

| Command | What it does |
|---------|--------------|
| `DOPS start` / `DOPS morning` / `DOPS briefing` | Trigger the morning briefing manually |
| `DOPS drain` | Trigger the capture drain manually |
| `DOPS sync` / `DOPS close` | Trigger the afternoon sync manually |
| `DOPS check` | Status check without mail (what is open? what is coming today?) |
| `DOPS review` | Review preparation — highlights + numbers since the last cycle |
| `DOPS care` | Ad-hoc customer stakeholder maintenance (gap list) |
| `DOPS urlaub` | Vacation balance + open submissions |

**Distinctive natural phrases (also work):**

- "Daily-Ops briefing" / "Daily-Ops sync"
- "Which tasks should I pull forward before my meeting on DD.MM. with X?"
- "Who are the stakeholders at [customer]?"
- "Review preparation" / "Highlights log since the last review"

## When NOT to use this skill

- **Generic daily overview without customer context** → the built-in `daily-briefing` skill is lighter. If you just say "morning briefing" / "daily overview", the built-in skill is intentionally triggered — Daily-Ops Ext only fires on the `DOPS` prefix or "Daily-Ops".
- **Single-meeting recap or prep** → the `meeting-intel` skill is more targeted
- **Pure calendar maintenance** (move, decline) → `calendar-management` / `schedule-meeting`
- **Ad-hoc mail triage without customer context** → use mail tools directly

## How Cowork uses the skill

| Request | Loaded |
|---------|--------|
| Morning briefing (full routine) | `_meta` + 11 living JSONs + `goals.json` (active=true) + `Bulk-Sources.json` (selective load — chronicle filtered to last 90d) |
| Capture drain | `_meta` + `tasks.json` (open only) + `stakeholders-customer.json` (chronicle last 30d) + state file + `goals.json` (on demand for Goal-Done captures + category-intake Goal classification) |
| Afternoon sync | `_meta` + `tasks.json` + customer/stakeholder/project JSONs + today's morning briefing codes_map + capture mails + `goals.json` (active=true) |
| Weekend briefing | `_meta` + `tasks.json` (filtered `bereich="Privat"`) + `wichtige-daten.json` + customers (on-demand) |
| "Pull forward before meeting?" | `tasks.json` + calendar |
| "Stakeholders at customer X?" | `stakeholders-customer.json` + `Kunden/<slug>.json` |
| "Review preparation" | `highlights.json` + last 4 briefings |
| Goal adherence (Soll/Ist + slot suggestion) | `goals.json` (active=true) + calendar (events in active fenster) |
| Category-Intake scan | `goals.json` (only for `DOPS-Intake-Goal`) + `customers.json` + `stakeholders-customer.json` + `tasks.json` + `highlights.json` (writes per typed/auto classification) |

## Customizations

- **Region**: enter your public holidays and school holidays in `wichtige-daten.json` `ferien_frei` block
- **Roles**: in `stakeholders-internal.json`, roles are free-form — match your setup (e.g., account manager, solution architect, project lead, customer success manager)
- **Language**: templates are in English by default — section headings can be freely renamed
- **Internal domain**: in the scheduled-prompt text, replace `<INTERNAL_DOMAIN>` with your real domain so "external vs. internal people" is detected correctly
- **Sync times**: 07:00 / 15:30 are defaults. If your day is structured differently, adjust in the scheduled-prompt setup
- **OneDrive mirror folder name**: `daily-ops-readonly/` is the default. Rename freely; just keep the four scheduled prompts in sync.
