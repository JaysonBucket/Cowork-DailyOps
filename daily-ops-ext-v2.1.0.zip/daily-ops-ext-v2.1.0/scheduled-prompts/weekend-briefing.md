# Scheduled Prompt — Weekend Briefing (Sat/Sun 07:00)

**Recommended configuration:**
- Frequency: weekly
- Days: Saturday, Sunday
- Time: 07:00
- Mode: `inline`

**Important before setup:**

1. In the prompt text below, replace the placeholder `<SKILL_PATH>` with the real skill path.
2. Replace `<YOUR_MAIL>` with your own mail address.
3. Replace `<PERSONAL_MAIL_1>`, `<PERSONAL_MAIL_2>`, `<PERSONAL_MAIL_3>` with your personal mail addresses. Leave fields empty if you have fewer than 3 addresses.
4. Replace `<FAMILY_NAMES>` with a comma-separated list of display names from your personal circle.
5. Replace `<INTERNAL_DOMAIN>` with your work mail domain (used in the sanity check).

---

```text
Create my weekend briefing as the central personal preparation and send it as an HTML mail to me (recipients=['me']) with subject "Weekend briefing DD.MM. — Personal".

DATA SOURCE (NEW in 2.0.0): JSON only. NO xlsx.

GROUND RULE (critical): When in doubt, EXCLUDE. Better to miss a personal entry than to let a work entry slip through. This briefing is explicitly personal-only.

SELECTIVE LOAD (very narrow):
- _meta.json
- tasks.json (filter: bereich="Privat" only — work tasks are excluded entirely)
- wichtige-daten.json (personen_anlaesse, ferien_frei, urlaub blocks — all personal by definition)
- customers.json — NOT loaded (sanity check uses customer names, but read on demand only if the briefing draft contains a hit)
- All other files — NOT loaded

Collect in parallel:
- Today + next 7 days of calendar — STRICTLY only personal events (see PERSONAL FILTER below). Work events are ignored.
- Lead-time reminders from wichtige-daten.json personen_anlaesse (today's due lead-time days)
- School holidays in your region(s) starting today or in the next 7 days
- Vacation entries from wichtige-daten.json urlaub eintraege — personal by definition

PERSONAL FILTER (critical — determines what lands in the briefing):
An event counts as personal only if AT LEAST ONE of these hard criteria applies:
1. Attendees include at least one address from: <PERSONAL_MAIL_1>, <PERSONAL_MAIL_2>, <PERSONAL_MAIL_3>
2. Attendee display name is one of: <FAMILY_NAMES> (also without a visible mail)
3. Event has mail category/label "Privat" or "Familie"
4. Event matches an entry in wichtige-daten.json personen_anlaesse (birthday, anniversary etc.)
5. Event title contains personal indicators without work context: "Birthday", "Wedding anniversary", "Anniversary", "Family", "School", one of the family first names without firm/customer context

If an event is unclear → EXCLUDE.

A task counts as personal only if:
- bereich field equals exactly "Privat". Empty or "Beruf" = EXCLUDE.

VACATION SECTION:
For each entry in wichtige-daten.json urlaub.eintraege with von in [today, today+30]:
- "geplant" → list with marker "⚠️ Submission missing" + days remaining until von
- "eingereicht" → list with marker "⏳ Approval pending"
- "genehmigt" → list with marker "✓ approved"
- "storniert" → omit
Sort by von ascending. If no entries in window: omit the section entirely.

CARRYOVER REMINDER:
If any urlaub.bilanz row has unconsumed carryover AND uebertrag_frist within next 60 days: show a one-line carryover reminder. Otherwise omit.

BRIEFING MAIL LAYOUT (HTML, mobile-friendly):

Structure (Sat/Sun layout — personal prominent at top, compact):
1. Greeting + date + weekday
2. Today (events + tasks due today from tasks.json with bereich="Privat")
3. This week (events + tasks of the next 7 days)
4. Lead-time reminders (today's due reminders from wichtige-daten.json personen_anlaesse)
5. Upcoming holidays / time off (your region, next 7 days)
6. Vacation (next 30 days) — entries from urlaub.eintraege. Suppressed if empty.
7. Carryover reminder — only if a bilanz row has unconsumed carryover with uebertrag_frist ≤ 60 days. Otherwise hidden.
8. Personal tasks (open) — STRICTLY tasks.json entries with bereich="Privat" AND status ∈ {inbox, active}. Work tasks are excluded here, even if the title sounds personal.

For tasks: capture code with P prefix (P-MMDD-NN) instead of T. Mailto link as for work tasks.

SANITY CHECK before sending:
Scan the finished mail for work trigger words: "Workshop", "Sync", "Review", "Customer", "Contract renewal", customer names from customers.json (load on-demand if needed), @<INTERNAL_DOMAIN> addresses, mail domains of customers. If a hit is found in the briefing → STOP, remove the entry, recompose. Better empty and short than accidentally work content inside.

Cheatsheet block at the end:

  Personal capture cheatsheet:
  - P-MMDD-NN codes work the same as T codes
  - Status: done | progress | paused | reschedule
  - Ad-hoc personal task: subject "DOPS-NEW <description>", in body "Bereich: Privat"

Also write the briefing file <SKILL_PATH>/data/Briefings/YYYY-MM-DD-weekend.json with structure:
{
  "kind": "briefing_weekend",
  "date": "YYYY-MM-DD",
  "weekday": "Saturday" | "Sunday",
  "content_md": "<full briefing markdown>",
  "personal_codes_map": {...},
  "generated_at": "<ISO timestamp>"
}

MIRROR STEP (NEW in 2.0.0):
At end of run: same hash-diff PUT to OneDrive folder daily-ops-readonly/ as morning briefing.
- Compute MD5 of all JSONs in data/, compare with _meta.json hashes, PUT changed files
- Update _meta.json hashes + last_mirror, re-PUT _meta.json last
- On failure: log under sanity-check section ("Mirror skipped for <file>"), do NOT block briefing send

Language: English (or adjust). Pragmatic, short. On missing personal data, send a short briefing rather than filling work gaps.
```

---

## Customizations

- **`<SKILL_PATH>`**, **`<YOUR_MAIL>`**: as in the other prompts
- **`<PERSONAL_MAIL_1>, <PERSONAL_MAIL_2>, <PERSONAL_MAIL_3>`**: your personal mail addresses
- **`<FAMILY_NAMES>`**: comma-separated display names from your personal circle
- **`<INTERNAL_DOMAIN>`**: your work domain for the sanity check
- **Sanity check trigger words**: adapt to your industry — leave out entirely for purely private setups

## Migration notes (v1.7 → v2.0)

- All xlsx reads/writes replaced with JSON reads/writes
- bereich="Privat" filter applied at load time on tasks.json (no longer column-17 lookup)
- Vacation entries read from wichtige-daten.json urlaub block
- Mirror step added at end of run
- Briefing file format: .json with content_md wrapper (replaces .md)
