# Scheduled Prompt — Morning Briefing (07:00)

**Recommended configuration:**
- Frequency: weekly
- Days: Monday–Friday
- Time: 07:00
- Mode: `inline` (same session — Cowork learns your style over time)

**Important before setup:**

1. In the prompt text below, replace the placeholder `<SKILL_PATH>` with the real skill path of your environment (see SETUP.md for common values).
2. Replace `<YOUR_MAIL>` with your own mail address (all `mailto:` links go to yourself).
3. Replace `<INTERNAL_DOMAIN>` with your internal mail domain (e.g. `company.com`) — otherwise internal colleagues will be detected as external customer contacts.
4. Replace `<PERSONAL_MAIL_1>, <PERSONAL_MAIL_2>, <PERSONAL_MAIL_3>` and `<FAMILY_NAMES>` with your personal addresses/names. Leave fields empty if not applicable.
5. **Mail rule** for the DOPS-Capture folder is set up (instructions in SETUP.md).
6. **OneDrive mirror folder** `daily-ops-readonly/` exists in your personal OneDrive (auto-created on first run if missing).

---

```text
Create my morning briefing as the central daily preparation and send it as an HTML mail to me (recipients=['me']) with subject "Morning briefing DD.MM. — Top 3: <top task title>".

DATA SOURCE (NEW in 2.0.0): all working data lives as JSON in <SKILL_PATH>/data/. NO xlsx anywhere. NO Excel-lock retry. Read JSON via Read tool, write JSON via Write tool.

SELECTIVE LOAD (keep per-run context under 100 KB):
Read in parallel:
- _meta.json (always — for hashes/version/snapshot tracking)
- customers.json
- stakeholders-internal.json
- stakeholders-customer.json (filter chronicle entries to last 90 days when reading; full chronicle only on explicit follow-up)
- partners.json
- projects.json
- watchlist.json
- tasks.json (filter: status ∈ {inbox, active, blocked} + status=done with completed in last 7 days)
- wichtige-daten.json
- highlights.json (filter: last 90 days only — older highlights are read on review-cycle runs)
- Bulk-Sources.json
- goals.json (NEW in 2.1.0 — only goals with active=true)
- hours-log.json — DO NOT load in morning briefing (only afternoon sync needs it)

Collect in parallel:
- Today + next 14 days of calendar (events + status, attendee mails, flag categorized vs. uncategorized events)
- New mails since yesterday evening — read From + all CC addresses. IMPORTANT: exclude mails with `DOPS-` in the subject (those are your own captures from the day — they are processed by the afternoon sync, not by the morning briefing)
- New Teams messages in 1:1 and group chats since yesterday — read participants
- Watchlist hits in mail/Teams (people, buzzwords from watchlist.json items)
- Lead-time reminders from wichtige-daten.json personen_anlaesse (today's due lead-time days)
- School holidays in your region(s) starting today or in the next 7 days
- Vacation entries from wichtige-daten.json urlaub block (bilanz + eintraege)

BULK FILTERING (logic 0 — before everything else):
Before feeding mails/Teams into the other logics, classify each message against Bulk-Sources.json:
1. Match against sources list: exact sender / domain wildcard / subject pattern / chat name
2. If no match: check heuristics (>20 recipients, DL sender like noreply/news/digest/lists, typical bulk subjects, HTML with unsubscribe link, group chat with >15 participants without @-mention to me, no personal greeting). At least 2 hits → bulk candidate.
3. allowlist from Bulk-Sources.json ALWAYS takes precedence — never treat manager / customer domains as bulk, even on DL sends.

Treatment per message:
- "Ignore" → not in the briefing at all, move directly to mail folder "Archiv/Bulk" (create the folder if missing)
- "KeyPoints" → 1–2 sentences in the section "Bulk key points", then move to "Archiv/Bulk". Do NOT quote full text — only on explicit follow-up.
- "FullText" → feed into the main logics like a normal mail (task detection, watchlist, highlight detection)
- New bulk candidates without an entry in Bulk-Sources.json → list under "New bulk sources detected" with a treatment proposal, do NOT archive until I confirm.

IMPORTANT: bulk mails MUST NOT feed into people-meeting matching, customer stakeholder maintenance, or task detection. They are explicitly excluded from those logics.

PERSONAL FILTER (logic 0b — directly after bulk filtering, before all work logics):
Classify every meeting and every task into one of two buckets: work or personal.

Personal detection — ANY of these criteria is enough:
1. Calendar event has at least one attendee from: <PERSONAL_MAIL_1>, <PERSONAL_MAIL_2>, <PERSONAL_MAIL_3>
2. Calendar event has an attendee with a display name from: <FAMILY_NAMES> (also without a visible mail)
3. Calendar event has mail category/label "Privat" or "Familie"
4. Entry in wichtige-daten.json personen_anlaesse → automatically personal
5. tasks.json entry with field bereich="Privat"
6. Event title contains personal indicators without work context: "Birthday", "Wedding anniversary", "Anniversary", "Family", "School", one of the family first names

Treatment of personal events: NO capture code, NO mailto link. Own briefing section at the end. NOT in people-meeting matching with work tasks. NOT in customer stakeholder maintenance.

Treatment of personal tasks (bereich="Privat"): capture code with P-prefix instead of T (P-MMDD-NN). Own briefing section "Personal tasks (open)" — NOT in top 3. Mailto link works the same as for work tasks.

Treatment of new tasks from mails/Teams: default bereich="Beruf". If the mail is from or to one of the personal addresses: bereich="Privat".

Weekday layout:
- Mon–Fri: personal sections at the end of the briefing, compact. Top 3 is work-only.
- Sat/Sun: this prompt does not fire. Instead the separate weekend briefing runs (see scheduled-prompts/weekend-briefing.md).

PEOPLE-MEETING MATCHING (logic 1 — work only):
For every open task in tasks.json with the people field populated:
1. Search the calendar of the next 14 days for events with at least one of these people attending
2. If hit: write the next shared event into the task's "next_shared_meeting" field (format: "DD.MM. HH:MM Event title") and the date in "meeting_date"
3. If the shared event is BEFORE the deadline AND status="active" or "inbox": recommend in the briefing "Handle before meeting on DD.MM. with X" — own section "Pull forward before meeting"
4. If the shared event is AFTER the deadline: just note as info ("Follow-up conversation on DD.MM. with X")

For new tasks from mails/Teams: ALWAYS enter all From + CC addresses into people_emails (array) and the display names into people_names (array). source_type: "Mail", "Teams" or "Meeting". source_link: mail ID / chat link / event ID. ALSO set source_event_id when the source is a calendar event (for chronicle cross-reference).

CUSTOMER STAKEHOLDER MAINTENANCE (logic 2 — with chronicle cross-references):
When external people appear in mails/Teams/calendar events (mail domain is NOT @<INTERNAL_DOMAIN>), match them against stakeholders-customer.json:
1. Customer mapping: mail domain → customers.json by name match. If unclear, derive customer from mail/event context (subject, other attendees).
2. YES (existing stakeholder) → 
   - Update last_contact_event_id on the stakeholder record
   - chronicle_log: append a chronicle entry with ts=now, entry="Contact via <channel>", topic=<inferred from subject>, event_id=<event id if calendar>, event_subject=<event subject>
3. NO (new stakeholder) → create a new entry in stakeholders-customer.json with: customer_id, name, email, role="?", decision_level="?", first_contact=today, first_contact_occasion=<channel/event subject>, last_contact_event_id=<event id>. Initial chronicle entry with the same data.
4. Also update Kunden/<slug>.json content_md "## People / Stakeholders" section. Bump the chronicle on the customer file too.

NOTES + CHRONICLE OPERATIONS VOCABULARY (NEW in 2.0.0):
Every record (customer, stakeholder, project, partner, task, watchlist item, holiday, vacation entry, highlight, kunden-md) has notes (free text, single field) and chronicle (timestamped array). Operations:
- note_replace(record_id, text)        — overwrite the notes field
- note_append(record_id, text)         — append "\n— DD.MM.: <text>" to existing notes
- note_clear(record_id)                — set notes to ""
- chronicle_log(record_id, entry, topic?, event_id?, event_subject?, outcome?, follow_up_task_ids?) — append timestamped entry
- chronicle_edit(record_id, ts, fields) — edit one chronicle entry by timestamp (rare; use only on user request)
- chronicle_link(record_id, ts, event_id, event_subject) — backfill an event_id on an existing chronicle entry

Use chronicle_log liberally on stakeholder contact events; sparsely on customers/projects (only material status changes).

CAPTURE CODE ASSIGNMENT (logic 3):
Assign every entry in the briefing a unique capture code per schema:
- Work tasks: T-MMDD-NN (NN = sequential number per day, starting at 01)
- Personal tasks (bereich="Privat"): P-MMDD-NN (separate sequential numbering per day, starting at 01)
- Meetings (work): M-MMDD-XX (XX = short tag from event title, max 6 chars, uppercase, no special chars)
- Personal events: NO code
- For tasks: write the code into the capture_code field of tasks.json (do not overwrite if already filled — existing codes stay stable across multiple days!)
- For meetings: code is generated only for the briefing, not persisted (meetings have event IDs)

MAILTO LINK GENERATION (logic 4):
For every capture code in the briefing, generate a mailto: link with URL-encoded subject and body. Recipient is always <YOUR_MAIL>.

Schema for tasks:
  Subject: "DOPS-<CAPTURE-CODE> <task title>"
  Body:
    Status: [done | progress | paused | reschedule]

    Note:

    ---
    Context: <task title>, due <DD.MM.>, people: <people names>, source: <source type>

Schema for meetings:
  Subject: "DOPS-<CAPTURE-CODE> <event title>"
  Body:
    Notes:

    New stakeholders: (Name <Mail>, Role)
    Follow-up tasks: (description — Cowork creates an inbox entry automatically)

    ---
    Context: <event title>, <DD.MM. HH:MM>-<HH:MM>, attendees: <attendee list>

Schema for ad-hoc task:
  Subject: "DOPS-NEW <short-description>"
  Body:
    Description:
    Due:
    People:
    Bereich: [Beruf | Privat]
    Priority: [P1 | P2 | P3]

URL encoding: space → %20, newline → %0A, colon → %3A, pipe → %7C, square brackets → %5B/%5D, comma → %2C, hyphen stays as -.

LENGTH LIMIT (critical — otherwise mail clients/browsers will not open the link):
Mail clients reliably accept mailto URLs up to ~2000 characters. Compute total URL length per entry BEFORE inserting into the HTML.

Tier 1 (default): full body. Verify URL length.
Tier 2 (URL > 1800 chars): trim the context block after `---` — keep only title + date. Add hint line: "Full context in the daily briefing: <SKILL_PATH>/data/Briefings/YYYY-MM-DD-morning.json".
Tier 3 (still > 1900 chars): drop the context block entirely. Display "📎 context trimmed" next to the entry in the briefing HTML.

In the NORMAL CASE (>95% of tasks/meetings) tier 1 is enough.

IMPORTANT: notes ALWAYS go AFTER the `---` separator, never before — the afternoon sync parser ignores everything after `---` as a context block. If notes appear before `---`, they would be interpreted as user input and break the status parser.

VACATION TRACKING (logic 5 — event-driven recalculation, NEW in 2.0.0):
Read wichtige-daten.json urlaub block. Three sub-blocks of work.

(5a) STALE-FLAG RECALCULATION:
If urlaub.bilanz[year].stale=true OR urlaub.bilanz[year].last_calculated < (today − 7 days, indicating drift):
1. For the current year, sum tage of all eintraege where status ≠ "storniert" and YEAR(von) = current year.
2. Update verbraucht = sum.
3. Update verbleibend = anspruch + uebertrag_vorjahr − verbraucht.
4. Set stale=false, last_calculated=now (ISO timestamp).
5. trigger_recalc_on stays as ["calendar-change", "manual", "year-rollover"] — these are the events that set stale=true (afternoon sync handles calendar-change detection; user can set stale via capture mail "DOPS-NEW Urlaub-Recalc"; year-rollover triggers on first weekday of new year, see 5b).

(5b) YEAR ROLLOVER (only on the first weekday of a new calendar year, or if the current year has no row in bilanz):
1. Determine the current year (today's year).
2. Check bilanz for a row with jahr = current year.
3. If MISSING:
   - Read config.default_anspruch and config.max_rollover_tage.
   - Compute uebertrag_vorjahr = MIN(verbleibend of previous-year row, max_rollover_tage). If previous year has no row: uebertrag_vorjahr = 0.
   - Insert a new bilanz row: jahr=current_year, anspruch=default_anspruch, uebertrag_vorjahr=computed, uebertrag_frist="<current_year+1>-06-30", verbraucht=0, verbleibend=anspruch+uebertrag_vorjahr, last_calculated=now, stale=false, trigger_recalc_on=["calendar-change","manual","year-rollover"].
   - Surface in the briefing under section "Year rollover": "New vacation year YYYY — entitlement X days, carryover Y days from previous year (must be taken by 30.06.<YYYY+1>). Please confirm or adjust."
   - This confirmation surface stays in the briefing for 3 consecutive days or until the user touches the bilanz row (whichever first).

(5c) DAILY VACATION ALERTS (every run):
For each entry in eintraege with status ∈ {geplant, eingereicht}:
- Compute days_until_start = (von date) − today.
- If status="geplant" (extern booked, not yet officially submitted — high alarm priority):
  - days_until_start ≤ 60: surface in briefing section "Vacation requests pending submission" — line "<bezeichnung> <von>–<bis> — externally booked, submission missing for X days, start in Y days"
  - days_until_start ≤ 30: same section, escalated tone ("⚠️ Submission urgent")
  - days_until_start ≤ 14: escalate to Top 3 of the day as P1 (treat as if it were a P1 task with deadline=von date)
  - days_until_start ≤ 7: same daily until the status changes
- If status="eingereicht" (submitted, awaiting approval):
  - days_until_start ≤ 14: surface in briefing section "Vacation requests submitted — awaiting approval" — single line, no escalation
- If status="genehmigt": no alert needed; vacation reflected in verbraucht and shows up only in section 12 (upcoming time off).

(5d) CARRYOVER DEADLINE ALERT:
For each bilanz row where uebertrag_vorjahr > 0 AND verbraucht < uebertrag_vorjahr (carryover days not yet consumed):
- Compute days_until_deadline = (uebertrag_frist) − today.
- ≤ 60: surface in section "Vacation balance" — "YYYY: Z carryover days unused, deadline DD.MM. (in W days)"
- ≤ 30: escalated ("⚠️ Carryover days expire in W days — book vacation now")
- ≤ 14: escalate to Top 3 as P1 task "Plan carryover vacation before DD.MM."
- After deadline: clamp verbleibend, surface one-time line "YYYY: N carryover days expired (carryover deadline passed)".

PERSONAL FILTER INTERACTION: vacation entries are personal by definition. They appear in the briefing's vacation sections (5b/5c) AND in section 13 if von is within the 7-day horizon. They do NOT generate a capture code.

GOAL ADHERENCE CHECK (logic 6 — NEW in 2.1.0):
Read goals.json. For every goal with active=true, evaluate Soll/Ist over its `fenster` against the calendar.

(6a) FENSTER-RESOLVING:
- "rolling-7d"      → today − 6 days … today (inclusive). Hits-Fenster für Briefing-Anzeige: today − 6 days … today.
- "calendar-week"   → Mon … Sun of the current ISO week.
- "rolling-30d"     → today − 29 days … today.
- "calendar-month"  → 1st … last day of current month.
- "daily"           → today only (used for streak goals).

(6b) MATCHING (per goal):
For every calendar event in the active fenster:
1. If goal.match.kalender_kategorien is non-empty: count event as a hit ONLY when at least one of these categories is on the event's categories array.
2. Else if goal.match.title_keywords is non-empty: case-insensitive substring match on event subject (any keyword hit = match).
3. Apply min_duration_min (default 0): event duration in minutes must be ≥ this value.
4. Apply optional show_as_filter (default: exclude show_as="free").
5. For anti_goal type with exclude_categories: events matching any excluded category do NOT count toward the limit.
6. Hits = matching events. For zeitbudget goals, ist_minuten = sum of durations of matching events.

(6c) EVALUATION (per goal type):
- KADENZ: ist_count = number of hits in fenster. soll = goal.soll_pro_fenster. status = "erreicht" if ist_count ≥ soll, else "offen". Lücke = soll − ist_count.
- ZEITBUDGET: ist_minuten = sum of durations. soll_minuten = goal.soll_minuten_pro_fenster. status = "erreicht" if ist_minuten ≥ soll_minuten, else "offen". Lücke = soll_minuten − ist_minuten (in minutes).
- STREAK: walk back day by day starting today; for each day check if any matching event with min_duration_min exists. Continue while hits exist; stop on first day without hit. current_streak = consecutive days incl. today (or until yesterday if today not yet logged). Update goal.current_streak; bump goal.longest_streak if exceeded. status = "erreicht" if today already has a hit, else "offen heute".
- ANTI_GOAL: ist_count = number of matching events in fenster minus exclude-category events. status = "ok" if ist_count ≤ max_pro_fenster, "warnung" if ist_count is within last 20% of limit, "überschritten" if ist_count > max_pro_fenster.

(6d) SLOT SUGGESTION (manual creation — no auto-create):
For each goal with status="offen" or "offen heute" AND goal.preferred_slot is non-null:
1. Find the next free 60-minute window (or duration_min from preferred_slot) that:
   - Is on a weekday in preferred_slot.weekdays
   - Starts at or after preferred_slot.time on that day (±60 min tolerance)
   - Has no conflicting calendar event (free/busy = "free")
   - Lies within the next 7 days
2. If found: write the suggestion line in the briefing under section "Goals this week":
   "<title> — <ist>/<soll> in <fenster>. Suggestion: <Weekday DD.MM.> <HH:MM>–<HH:MM> (Outlook: book the slot manually)"
3. NO mailto link, NO auto-create. The slot suggestion is information only — User books the slot manually in Outlook.
4. ALTERNATIVE: if you want to log a goal completion outside the calendar (e.g. spontaneously gone for a run without an event), use a capture mail: subject "DOPS-NEW Goal-Done <goal_id> <YYYY-MM-DD>", body Note: optional. The capture-drain handler appends a manual hit to goal.history.

(6e) ANTI-GOAL ESCALATION:
- status="warnung": single line in section "Goals this week", e.g. "Meeting limit — 21/25 (warning, 4 slots remaining)".
- status="überschritten": escalate to Top 3 area as P2 ("Meeting limit exceeded: 27/25 — where can we cut back?"). No mailto, just info.

(6f) CHRONICLE:
- If a goal flips from "offen" to "erreicht" today (i.e. yesterday was offen, today erreicht): chronicle_log(goal_id, "Target reached: <ist>/<soll>", topic="adherence").
- If a streak goal breaks (current_streak resets from >0 to 0): chronicle_log(goal_id, "Streak broken after <prev> days", topic="streak-break").
- Anti-Goal überschritten: chronicle_log(goal_id, "Limit exceeded: <ist>/<max>", topic="limit-exceeded").

WRITE-BACK to goals.json: only on flips/changes (status transitions, streak updates, hit additions). No write if nothing changed — keeps the mirror diff small.

BRIEFING MAIL LAYOUT (HTML, mobile-friendly):
The mail must be readable on mobile — short paragraphs, no wide tables, clear buttons.

Structure:
1. Greeting + date
2. Top 3 for today (P1 tasks from tasks.json status=inbox/active) — per entry: title, code in parentheses, mailto link "Send update". Vacation alerts that escalated to P1 appear here too — code is the bilanz year (e.g. "Urlaub 2026") or the entry's id, no mailto link, just the alert text.
3. Pull forward before meeting — per entry: "T-XXXX-NN — task XYZ before meeting DD.MM. with person" + mailto link
4. Today's events — per entry: "M-XXXX-XX — time title, attendees" + mailto link "Send notes"
5. Lead-time alerts (personal dates from wichtige-daten.json personen_anlaesse)
6. Watchlist hits since yesterday
7. New tasks since yesterday (identified from mails/Teams) — already entered in tasks.json WITH people fields and capture code
8. New customer contacts (newly created today — role/level open)
9. Highlight detection (positive customer mails, completed milestones yesterday)
10. Bulk key points
11. New bulk sources detected
12. Upcoming holidays / time off in your region
13. Personal events today & next 7 days (compact, at the end)
14. Personal tasks (open) (bereich="Privat" from tasks.json, with P codes)
15. Goals this week (NEW in 2.1.0 — Soll/Ist per active goal, slot suggestions for open gaps, anti-goal warnings)
16. Year rollover (only when triggered — see logic 5b)
17. Vacation requests pending submission (entries with status="geplant" within 60 days)
18. Vacation requests submitted — awaiting approval (entries with status="eingereicht" within 14 days)
19. Vacation balance (only if carryover days at risk per logic 5d, OR after carryover deadline passed)

Cheatsheet block at the end:
  Capture cheatsheet:
  - Click "Send update" / "Send notes" — mail opens pre-filled
  - Status word in the 1st line (done | progress | paused | reschedule)
  - Note underneath, leave the rest unchanged
  - Ad-hoc task: new mail, subject "DOPS-NEW short-description"
  - Folded in by the daily sync at 15:30

Also write the briefing file <SKILL_PATH>/data/Briefings/YYYY-MM-DD-morning.json with structure:
{
  "kind": "briefing_morning",
  "date": "YYYY-MM-DD",
  "weekday": "Monday",
  "content_md": "<full briefing markdown without mailto links>",
  "codes_map": {
    "T-0503-01": {"task_id": "tsk_xxxx", "title": "..."},
    "M-0503-PRSYNC": {"event_id": "evt_xxxx", "subject": "..."},
    ...
  },
  "vacation_state_snapshot": {
    "bilanz_2026": {"verbraucht": 15.5, "verbleibend": 14.5, "stale": false}
  },
  "generated_at": "<ISO timestamp>"
}

Enter new tasks into tasks.json (status="inbox"). Track detected highlights as proposed in highlights.json (entries get added with status field "proposed" — actual confirmation by user via afternoon sync). Update customers.json last_contact_event_id and chronicle. For confirmed bulk sources add an entry to Bulk-Sources.json sources array.

MIRROR STEP (NEW in 2.0.0 — at the END of the run):
After all data writes are complete, mirror changed JSONs to OneDrive folder "daily-ops-readonly":
1. Compute MD5 hash of every file in <SKILL_PATH>/data/ (recursive: includes Briefings/, Kunden/, Meeting-Notes/).
2. Compare each hash against _meta.json files.<filename>.hash.
3. For each file where hash differs OR _meta.json has no hash entry: PUT the JSON content to OneDrive via Graph API (path /me/drive/items/<daily-ops-readonly_id>:/<filename>:/content). For subfolder files (Briefings/X.json, Kunden/Y.json, Meeting-Notes/Z.json): PUT to /me/drive/items/<daily-ops-readonly_id>:/Briefings/X.json:/content (auto-creates subfolders).
4. Update _meta.json files.<filename>.hash and files.<filename>.last_mirror=now.
5. Update _meta.json.last_mirror=now. _meta.json itself is mirrored last (hash of _meta.json includes all the new hash values from step 4).
6. Re-PUT the updated _meta.json.

If a PUT fails: log under Needs review in the briefing mail ("Mirror skipped for <file> — Graph API error: <code>"). Do NOT block the briefing send.

ADDITIONALLY ON MONDAY (no longer needed for backup — the daily snapshot folder handles it; see afternoon-sync.md). Monday no longer carries extra work in the morning briefing.

Language: English (or adjust). Pragmatic, no sugarcoating. On missing data/stakeholders flag actively rather than papering over gaps.
```

---

## Customizations

- **`<SKILL_PATH>`**: replace fully before the first run
- **`<YOUR_MAIL>`**: your own mail address for the mailto links
- **`<INTERNAL_DOMAIN>`**: your internal mail domain
- **Language, region**: as in previous versions

## Migration notes (v1.7 → v2.0)

- All xlsx reads/writes replaced with JSON reads/writes via Read/Write tools
- Excel-lock-aware retry logic removed (no longer applicable)
- Selective load model — capture-drain and afternoon-sync read narrower subsets
- Mirror step added at end of run — folder `daily-ops-readonly/` in personal OneDrive
- Monday backup step removed — replaced by daily snapshots from afternoon-sync
- Notes + Chronicle pattern available on every record via the operations vocabulary
