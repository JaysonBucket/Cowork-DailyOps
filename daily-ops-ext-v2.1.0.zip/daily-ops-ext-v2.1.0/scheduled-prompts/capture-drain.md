# Scheduled Prompt — Capture Drain (10:00 / 12:00 / 14:00)

**Recommended configuration:**
- Frequency: weekly
- Days: Monday–Friday
- Times: 10:00, 12:00, 14:00 (three short runs between morning briefing and afternoon sync)
- Mode: `inline` (same session — uses the same lookup tables as morning + afternoon)

**Purpose:** lightweight in-between sync. Folds the captures that have arrived since the last run into tasks.json + stakeholders-customer.json so the inbox stays fresh between morning briefing and afternoon sync. **Silent unless something needs your attention** — no daily noise.

**Important before setup:**

1. Replace `<SKILL_PATH>`, `<YOUR_MAIL>`, `<PERSONAL_MAIL_1>, <PERSONAL_MAIL_2>, <PERSONAL_MAIL_3>`, `` exactly as in afternoon-sync.md (same allowlist applies).
2. Mail rule for `DOPS-Capture` folder must be in place (same as for the afternoon sync).
3. Today's morning briefing file must exist at `<SKILL_PATH>/data/Briefings/YYYY-MM-DD-morning.json` with codes_map field (otherwise this run skips and waits for the next slot).

---

```text
Run the capture drain — fold the captures that have arrived since the last drain (or since the morning briefing) into tasks.json and stakeholders-customer.json. Lightweight, silent unless I need to look at something.

DATA SOURCE (NEW in 2.0.0): JSON only. NO xlsx. NO Excel-lock retry needed.

SCOPE (critical — what this run does NOT do):
- NO highlight detection (only the afternoon sync does that)
- NO end-of-day proposal / Top-3-for-tomorrow (only the afternoon sync)
- NO sync report mail by default — the run is silent unless there is Needs review
- NO meeting-notes archival of full text (defer to afternoon sync — but new stakeholders + follow-up tasks ARE folded in)
- NO customer-MD updates (defer to afternoon sync)
- NO mirror step (defer to afternoon sync — drains are too frequent for full mirror)

This is by design — the capture drain only does what is needed to keep tasks.json and stakeholders-customer.json fresh during the day. Heavy synthesis stays in the afternoon sync.

SELECTIVE LOAD (lighter than morning briefing):
- _meta.json
- tasks.json (filter: status ∈ {inbox, active, blocked} only)
- stakeholders-customer.json (filter: chronicle last 30 days)
- Briefings/YYYY-MM-DD-morning.json (codes_map field)
- .drain-state.json (state file)
- Bulk-Sources.json — NOT needed (afternoon sync handles bulk sources)
- customers.json — only on demand (when an M-code capture arrives with a stakeholder that needs customer mapping, or when a category-intake mail needs customer mapping)
- goals.json — only on demand (when a "DOPS-NEW Goal-Done" capture arrives, NEW in 2.1.0)
- highlights.json, hours-log.json, watchlist.json, wichtige-daten.json — NOT loaded

STEP 0: Security filter (identical to afternoon sync)
Trusted sender allowlist:
- <YOUR_MAIL>
- <PERSONAL_MAIL_1>, <PERSONAL_MAIL_2>, <PERSONAL_MAIL_3>
- 

Match From (case-insensitive). No match → move to DOPS-Capture/_rejected/YYYY-MM-DD/, list under "Needs review" (the run will mail this — see step 5), do NOT process.

STEP 1: Find new captures since last drain
- Read all mails in mail folder "DOPS-Capture" with received timestamp AFTER the last successful run (state file: <SKILL_PATH>/data/.drain-state.json — key "last_run_iso"). On first run of the day: use today 00:00 local as the lower bound.
- If the folder has no new captures since last run: end the run silently (no mail, no log entry beyond a state-file timestamp update). Do NOT send "all quiet" mails.

STEP 2: Codes map lookup
- Read <SKILL_PATH>/data/Briefings/YYYY-MM-DD-morning.json codes_map field
- Read tasks.json — for all open tasks the capture_code field is the lookup key (multi-day codes carry over)
- Build code → task_id / event_id lookup

If today's morning briefing file is missing (e.g. user was offline this morning): SKIP the run, log "no morning briefing — drain deferred to next slot" in the state file, do not mail.

STEP 3: Classify and fold in
For each new capture mail:

PER TASK UPDATE (T-MMDD-NN or P-MMDD-NN):
- "done"       → tasks.json: status="done", completed=now, append note via note_append, capture_code stays
- "progress"   → tasks.json: status="active", note_append("<DD.MM.>: <text>")
- "paused"     → tasks.json: status="blocked", note_append("<DD.MM.> paused: <reason>")
- "reschedule" → if a deadline is in the body, update due_date; if not, hold under Needs review
- Unrecognized status → Needs review

Also: chronicle_log on the task — entry="<status>", outcome=<note text first 80 chars>, ts=now.

PER MEETING NOTE (M-MMDD-XX):
- Parse "New stakeholders" → fold into stakeholders-customer.json (last_contact_event_id=event_id from morning briefing's codes_map; chronicle_log with topic from notes). Customer-md update is DEFERRED to afternoon sync.
- Parse "Follow-up tasks" → create tasks.json entries with status="inbox", priority="P2" default, source_event_id=<event_id>, capture_code is assigned by the next morning briefing.
- DO NOT yet write Meeting-Notes/<date>-<code>.json — leave the original mail in DOPS-Capture (the afternoon sync archives it). Avoids partial files.
- Mark the mail with category "DOPS-drained" so the afternoon sync skips the inbox-fold step but still archives the full notes-md.

PER AD-HOC TASK (DOPS-NEW):
- Special subjects (handled BEFORE the generic ad-hoc creation):
  - "DOPS-NEW Mirror-Now"      → trigger an immediate OneDrive mirror in this run (see hook description below); do NOT create a task; archive the mail with category "DOPS-drained-action".
  - "DOPS-NEW Urlaub-Recalc"   → set wichtige-daten.json urlaub.bilanz[<current_year>].stale=true; the next morning briefing recomputes; archive the mail with category "DOPS-drained-action".
  - "DOPS-NEW Goal-Done <goal_id> <YYYY-MM-DD>" (NEW in 2.1.0) → log a manual goal hit:
      1. Load goals.json on demand. Locate goal by id; if missing → Needs review.
      2. Append a history entry: {"date": "<YYYY-MM-DD>", "source": "manual-capture", "duration_min": <body field "Duration:" or null>, "note": <body field "Note:" or "">, "ts": <now>}.
      3. For streak goals: if date is today AND today not yet in current_streak: increment current_streak (and longest_streak if exceeded). For older dates: only re-evaluate on next morning briefing's logic 6.
      4. chronicle_log(goal_id, "Manual hit logged for <YYYY-MM-DD>", topic="manual-log", outcome=<note>).
      5. Archive the mail with category "DOPS-drained-action". Do NOT create a task.
- Generic case: Create tasks.json entry with status="inbox", source_type="Self", bereich="Beruf"/"Privat" per body field, capture_code assigned by next morning briefing.

STEP 4: Archive only finalized captures
- Mails for task updates (T- and P- codes) and ad-hoc tasks: move to DOPS-Capture/_processed/YYYY-MM-DD/.
- Mails for meeting notes (M- codes): LEAVE IN DOPS-Capture (afternoon sync archives them). Mark with category "DOPS-drained".
- Parser errors: move to DOPS-Capture/_review/.

STEP 5: Needs review mail (only if needed)
If — and only if — at least one of the following happened during this run:
- A capture was rejected by the security filter
- A status word was unrecognized
- A "reschedule" capture was missing a deadline
- An M-code mail had a parser error

… send a short HTML mail to me (recipients=['me']) with subject "Capture drain HH:MM — Needs review (N items)" listing only the items that need attention. Cap at 5 items in the body — if more, mention "+ N more, see afternoon sync".

If everything went through cleanly: NO mail, just update the state file timestamp.

STEP 6: Category-Intake scan (NEW in 2.1.0 — additive intake channel without DOPS-mailto)
Category-Intake lets the user tag any Outlook mail or calendar event with a category to feed it into Daily-Ops without forwarding/composing a DOPS-capture mail. The drain scans, classifies, processes, and removes the category afterwards so nothing gets re-processed.

Two category families:
- AUTO       → "DOPS-Intake"            : let the drain auto-classify (Mail → Task or Customer-Update; Event → Meeting note + Stakeholder fold)
- TYPED      → "DOPS-Intake-Task"       : force task creation
                "DOPS-Intake-Customer"  : force customer/stakeholder maintenance only (no task)
                "DOPS-Intake-Highlight" : propose as highlight (status="proposed" in highlights.json — afternoon sync confirms)
                "DOPS-Intake-Goal"      : log a goal hit if a goal matches the event/mail context (use the calendar event's category match logic from logic 6 to determine which goal)

Override precedence: any TYPED category overrides AUTO if both are present.

(6a) MAIL SCAN:
- Use ListMessages with $filter on categories/any(c: c eq 'DOPS-Intake') OR c eq 'DOPS-Intake-Task' OR c eq 'DOPS-Intake-Customer' OR c eq 'DOPS-Intake-Highlight' (single Graph call per category family — at most 4 calls).
- Apply the SAME security filter as STEP 0 (trusted sender allowlist). External senders → leave the mail untouched, surface under Needs review as "External category-intake item from <sender> — not processed for security".

For each mail:
- AUTO classification heuristics:
  - Sender = my own / personal address AND body has a verb-like first line ("Remind me to…", "Do…", "Ask…") → Task (status="inbox", source_type="Self").
  - Sender = customer domain AND mail discusses a person/contact change (new contact, role change) → Customer-Update (stakeholders-customer.json fold + chronicle_log on customer).
  - Sender = customer domain, generic mail content → Task with people_emails=[sender + cc], source_type="Mail", source_link=<message id>.
  - When in doubt → Task with body excerpt as description; flag in Needs review as "Auto-classified as Task — please confirm".
- TYPED Task        → tasks.json entry, status="inbox", subject=mail subject, description=first 280 chars of body, source_type="Mail", source_link=<message id>, people_emails=[sender + cc filtered through bulk-rules], people_names=resolved.
- TYPED Customer    → stakeholders-customer.json fold (same logic as morning-briefing logic 2). chronicle_log on the stakeholder + on customers.json. NO task created.
- TYPED Highlight   → highlights.json append entry with status="proposed", quelle=<message id>, datum=today, beschreibung=mail subject + first 200 chars, bereich="Beruf"/"Privat" inferred from sender.
- TYPED Goal        → load goals.json on demand. Try to match the mail's subject/body against goals[].match.title_keywords. If unique match → append history entry as "manual-log" with date=today; chronicle_log goal. If multiple/no match → Needs review.

After successful processing per mail:
- Remove the category via UpdateMessage(message_id, categories=<existing minus DOPS-Intake* categories>).
- ALSO add category "DOPS-Intake-Done" so the user sees a visual confirmation in Outlook (manual sweep / cleanup possible).
- Move the mail to mail folder "DOPS-Capture/_processed/YYYY-MM-DD/" (same archive convention as DOPS-mailto captures).

If processing fails: leave the category untouched, log under Needs review with reason. The next drain will retry.

(6b) CALENDAR SCAN:
- Use ListCalendarView for today − 1d … today + 14d with $filter on categories/any(c: c eq 'DOPS-Intake' or c eq 'DOPS-Intake-Task' or c eq 'DOPS-Intake-Customer' or c eq 'DOPS-Intake-Highlight' or c eq 'DOPS-Intake-Goal').

For each event:
- AUTO classification heuristics:
  - Past event (end < now) AND has external attendees → Meeting Note + Stakeholder fold (use STEP 3 PER MEETING NOTE logic, attendees as new stakeholders if not already in customer-list, chronicle_log linking event_id).
  - Future event AND title implies a deliverable for me → Task with due_date = event.start, source_type="Meeting", source_event_id=event.id.
  - When in doubt → Meeting Note (defer full archival to afternoon sync; do the stakeholder fold now).
- TYPED Task        → tasks.json entry, due_date=event.start, source_type="Meeting", source_event_id=event.id, people_emails=event.attendees, status="inbox".
- TYPED Customer    → stakeholders fold from attendees only. NO task. NO meeting note (afternoon sync handles full meeting-note archival).
- TYPED Highlight   → highlights.json proposed entry with quelle=event.id, datum=event.start.
- TYPED Goal        → load goals.json. Match event title/categories against goals[].match. If unique match → append history entry: {"date": <event.start date>, "source": "category-intake", "duration_min": <event duration>, "event_id": event.id, "ts": now}. chronicle_log. For streak: re-evaluate via logic 6c on next morning briefing.

After successful processing per event:
- Remove the DOPS-Intake* category via UpdateEvent(event_id, categories=<existing minus DOPS-Intake* categories>).
- Add category "DOPS-Intake-Done" for visual confirmation.

(6c) WRITE-BACKS + KLÄRUNGSBEDARF:
- All STEP 6 writes (tasks/stakeholders/customers/highlights/goals) flush at the end of STEP 6, BEFORE the state file write.
- If category-intake produced any Needs review items, append them to the existing Needs review list from STEP 5 — re-send the mail with the combined items if STEP 5 already triggered, else fire STEP 5 now if intake-only Needs review exists.

DESIGN NOTE: Category-Intake is additive. The DOPS-mailto capture pipeline stays the primary channel — Category-Intake is for the "I'm in Outlook anyway, just tagging this" case.

STEP 7: State file update
- Write <SKILL_PATH>/data/.drain-state.json with:
  - "last_run_iso": <now>
  - "captures_processed": <count>
  - "klaerungsbedarf": <count>
  - "skipped_reason": "" or one of {"no_captures","no_morning_briefing"}
- Keep only the last 5 runs in a rolling "history" array.

NO MIRROR STEP (NEW in 2.0.0):
The capture drain does NOT mirror to OneDrive. The afternoon sync handles the mirror after the day's heavy synthesis is done. Three drains per day pushing partial state would burn Graph API calls without benefit — the user reads the OneDrive copy mostly mornings and evenings.

If you absolutely need an interim mirror state (e.g. travel day with no laptop access): set bereich="Beruf" and subject "DOPS-NEW Mirror-Now" — this triggers a mirror in the next drain run via the ad-hoc task hook (catch this in STEP 3 PER AD-HOC TASK and run the mirror immediately, then mark the task done in the same run).

Language: English (or adjust). Silent unless action is needed. The user does NOT want a mail for "everything was fine".
```

---

## Customizations

- **Times**: 10:00 / 12:00 / 14:00 are sensible defaults — three short runs between morning briefing (07:00) and afternoon sync (15:30). If your day starts later, shift to 11/13/15. If your captures are mostly bursty around lunch, two slots (12:00, 14:00) are enough. Do not run more than every 90 min.
- **State file**: lives at `<SKILL_PATH>/data/.drain-state.json`. Already covered by the `_review/`, `_rejected/`, `_processed/` patterns; the JSON is tiny but personal. On first run after install, the file is created automatically.
- **When you're on holiday**: the run stays silent (no captures = no mail). On return it picks up where it left off.
- **Needs review cap**: default 5 items per drain mail. If you frequently get more, raise to 10 in the prompt.

## Migration notes (v1.7 → v2.0)

- All xlsx reads/writes replaced with JSON reads/writes
- Excel-lock-aware retry logic removed (no longer applicable to JSON)
- Selective load — drain reads only tasks.json + stakeholders-customer.json + state
- Mirror step deferred to afternoon-sync (drain is silent unless Needs review)
- Mirror-Now hook via DOPS-NEW for travel-day exceptions
