# Daily-Ops Ext — Setup-Guide

> **Generische Variante** ohne unternehmens-spezifische Begriffe — portabel über Branchen und Firmen hinweg. Funktional gleichwertig zur internen `daily-ops-ms`-Variante.

**Version 1.6.0** — siehe [CHANGELOG.md](CHANGELOG.md) für Änderungen.

Persönliches Daily-Operations-System für customer-facing Rollen (Account Manager, Consultants, Solution Architects, Projektleiter, Customer Success). Nach dem Import ca. 30–60 Min Initial-Setup, dann pflegt es sich weitgehend selbst.

## Was ist neu in 1.6.0

**Privat/Beruf-Trennung** — der Skill weiß ab jetzt, was beruflich ist und was privat:

- Tasks-Inbox.xlsx hat eine neue Spalte **Bereich** (Inbox Spalte 17 / Done Spalte 10) mit Dropdown `Beruf | Privat`. Alte Zeilen ohne Wert werden als Beruf behandelt — bestehende Tasks bleiben funktional.
- Privat-Tasks bekommen einen eigenen Capture-Code-Namespace: **P-MMDD-NN** (parallel zu T-MMDD-NN für Beruf).
- Im Mo–Fr Morning-Briefing sind die Privat-Sektionen kompakt am Ende; Top-3 bleibt strikt Beruf-only.
- **Wochenend-Briefing** als dritter Scheduled Prompt (`scheduled-prompts/weekend-briefing.md`, Sa/So 07:00) — strikt Privat-only, mit Sanity-Check auf Beruf-Triggerwörter (Workshop, Sync, Review, Customer, Kunden-Domains, …) und Grund-Regel „Im Zweifel AUSSCHLIESSEN".
- 6 harte Privat-Erkennungs-Kriterien im Briefing: Privat-Mail-Adressen, Familien-Namen, Mail-Kategorie „Privat"/„Familie", Eintrag in wichtige-daten.xlsx, Bereich="Privat", oder Privat-Indikatoren im Termintitel.

**Sicherheits-Filter im Afternoon-Sync (SCHRITT 0)** — Schutz gegen DOPS-Mail-Injection:

- Afternoon-Sync verarbeitet nur DOPS-Captures, deren From-Adresse auf der Allowlist steht: `<DEINE_MAIL>`, `<PRIVAT_MAIL_1..3>`, optional `<SAFE_SENDERS>`.
- Captures von fremden Absendern werden NICHT verarbeitet, sondern nach `DOPS-Capture/_rejected/YYYY-MM-DD/` verschoben und im Sync-Report unter „Klärungsbedarf" geflaggt.
- Konservativer Default: bei unklarem Header → ablehnen, nicht raten. Verhindert Risiko, dass jemand DOPS-formatierte Mails an dich schickt, um Tasks/Stakeholder/Meeting-Notes zu fälschen.

**Adhoc-Task-Schema erweitert** um `Bereich: [Beruf | Privat]`-Feld im Body. Default Beruf wenn leer oder ungültig.

**Migration aus 1.5.x:**
- Tasks-Inbox.xlsx: bei bestehenden Daten manuell die Bereich-Spalte (Spalte 17 Inbox / Spalte 10 Done) ergänzen oder Vorlage neu importieren. Leere Bereich-Zelle wird als Beruf interpretiert.
- **Drei** Scheduled Prompts setzen statt zwei: Morning-Briefing + Afternoon-Sync neu laden (mit den 1.6.0-Texten), zusätzlich Wochenend-Briefing für Sa/So 07:00 anlegen.
- **Pflicht** in allen drei Prompts: `<PRIVAT_MAIL_1..3>` und `<FAMILIEN_NAMEN>` befüllen, sonst greift der Privat-Filter nicht.
- **Pflicht** im Afternoon-Sync: `<SAFE_SENDERS>` einmal anschauen — leer lassen, wenn nur eigene + Privat-Adressen reichen.

## Was ist neu in 1.5.0

**Trigger-Schema umgebaut — `DOPS`-Prefix als Namespace:**

Der built-in `daily-briefing`-Skill und Daily-Ops Ext hatten kollidierende Trigger ("Morgen-Briefing", "Tagesüberblick", "morning briefing"). Ergebnis: oft sprang der falsche Skill an. Ab 1.5.0 nutzt Daily-Ops Ext einen klaren `DOPS`-Prefix-Namespace — analog zum bereits etablierten `DOPS-` im Capture-Subject.

**Befehls-Cheatsheet:**

| Befehl | Tut was |
|--------|---------|
| `DOPS start` / `DOPS morgen` / `DOPS briefing` | Morgen-Briefing manuell anstoßen |
| `DOPS sync` / `DOPS abschluss` | Afternoon-Sync manuell anstoßen |
| `DOPS check` | Status-Check ohne Mail |
| `DOPS review` | Review-Vorbereitung (Highlights + Numbers seit letztem Cycle) |
| `DOPS pflege` | Kunden-Stakeholder ad-hoc pflegen |

Zusätzlich funktionieren weiter distinktive Phrasen wie „Daily-Ops Briefing", „Vorziehen vor Termin", „Review-Vorbereitung", „Stakeholder bei [Kunde]".

**Bewusst entfernt** aus der Trigger-Liste: „Morgen-Briefing" (allein), „Tagesüberblick", „morning briefing", „neue Tasks für mich", „daily ops". Diese feuern jetzt absichtlich den built-in `daily-briefing` an — wenn du das volle Daily-Ops Ext willst, sag `DOPS start` oder „Daily-Ops Briefing".

**Migration aus 1.4.x:** keine Excel-Änderungen, keine Scheduled-Prompt-Änderungen. Nur SKILL.md neu laden lassen, damit die neue Description gezogen wird. Die zwei Scheduled Prompts (07:00 / 15:30) laufen unverändert weiter — das Trigger-Redesign betrifft nur manuelle Anfragen.

## Was ist neu in 1.4.1

- **Identifier-Wechsel**: `DOPS-` statt `DOPS#` als Subject-Prefix. Der Bindestrich tokenisiert in jedem Mail-Client (Outlook Classic Desktop, neues Outlook, Web, Mac, Gmail) zuverlässig — der Hash war in manchen Clients ein Risiko.
- **mailto-Längen-Logik**: Wenn der Capture-Link zu lang würde (>1800 Zeichen), kürzt Cowork den Kontext-Block automatisch und setzt einen Hinweis ins Body, dass der volle Kontext im Tagesbriefing-File steht. Damit gehen auch Tasks mit vielen Personen oder Meetings mit großer Teilnehmer-Liste sauber durch.
- **Versions-Sync mit ms-Variante**: Die ext-Variante zieht direkt von 1.0.0 auf 1.4.1 nach, damit beide Varianten auf gleichem Stand sind. Siehe CHANGELOG.md für Details der dazwischenliegenden Schritte (1.1, 1.2, 1.3, 1.4).

## Was ist neu in 1.4

- **Mail-Capture-Loop**: 07:00 Briefing kommt jetzt als Mail mit klickbaren Capture-Links für jede Task und jeden Termin. Du klickst → Mail öffnet vorbefüllt → Status oder Notiz tippen → abschicken. 15:30 arbeitet Cowork alle Captures ein.
- **Capture-Code-Schema**: `T-MMDD-NN` für Tasks, `M-MMDD-XX` für Meetings, `NEW` für Adhoc-Tasks. Im Subject als `DOPS-<CODE>` — eindeutig, kollidiert nicht mit normalen Mails.
- **Neuer Scheduled Prompt** `afternoon-sync.md` (15:30) — liest DOPS-Capture-Ordner, aktualisiert Tasks-Inbox, legt Meeting-Notes ab, schickt Sync-Report-Mail.
- **Schema-Erweiterung**: Tasks-Inbox.xlsx hat jetzt Spalte "Capture-Code" (Inbox + Done). Bei Update aus 1.0.x: Spalte wird beim ersten 07:00-Run automatisch gefüllt.

## 1. Skill importieren

Skill-Verzeichnis je nach Umgebung anlegen. Gängige Pfade:

```
~/.claude/skills/daily-ops-ext/                   # Claude-Code-CLI lokal
<OneDrive>/Apps/Claude/skills/daily-ops-ext/      # CLI mit Cloud-Sync
<Cowork-Cloud-Mount>/skills/daily-ops-ext/        # Cowork-Cloud-Container
```

Den realen Pfad merken — du brauchst ihn beim Scheduled-Prompt-Setup als Ersatz für den Platzhalter `<SKILL_PFAD>`.

Wichtig: Die Excel-Dateien müssen im **xlsx-Format (PK-zip)** bleiben. Wenn du sie in Excel öffnest, beim Speichern explizit "Excel-Arbeitsmappe (.xlsx)" wählen — nicht das Legacy-.xls-Format.

## 2. Initial-Befüllung (einmalig, ca. 30–60 Min)

### a) Cowork-Hub.xlsx

| Sheet | Was eintragen |
|-------|---------------|
| **Kunden** | Eine Zeile pro Kunde. Nur Name + Branche + Status — Rest minimal |
| **Interne Stakeholder** | Pro Kunde + Rolle eine Zeile. Rolle frei wählbar (z. B. Account Manager, Solution Architect, Projektleitung, Customer Success Manager) |
| **Watchlist** | Manager-Name + relevante Buzzwords (z. B. "Verlängerung", "Eskalation", "Beschwerde"). Cowork scannt Mails/Teams danach |
| **Kunden-Stakeholder** | Wächst automatisch — du kannst aber wichtige Personen vorab eintragen |

Beispiel-Zeilen sind grau hinterlegt — überschreiben oder löschen.

### b) Tasks-Inbox.xlsx

Leer lassen oder mit deinen aktuellen offenen Tasks befüllen. Wichtig:
- **Quelle-Typ**: Mail / Teams / Meeting / Selbst / Vertrag
- **Personen (Mail)**: kommagetrennt, damit Personen-Termin-Matching funktioniert
- **Personen (Namen)**: lesbare Form
- **Capture-Code**: leer lassen — wird beim ersten Morgen-Briefing-Run automatisch vergeben

### c) wichtige-daten.xlsx

| Sheet | Was eintragen |
|-------|---------------|
| **Personen & Anlässe** | Geburtstage, Jahrestage. Vorlauf-Tage z. B. `14,7,2` für 14/7/2 Tage vorher |
| **Ferien & Frei** | Feiertage und Schulferien deiner Region(en) |

### d) highlights.xlsx

| Sheet | Was eintragen |
|-------|---------------|
| **Review-Cycles** | Datum deines letzten Mitarbeiter-Reviews als Anker (Cowork rechnet darauf den nächsten Cycle) |
| **Numbers-Tracker** | Quartale anpassen, dann von Cowork auffüllen lassen |
| **Highlights-Log** | Cowork füllt selbst — du kannst aber Vergangenheit nachtragen |

### e) Bulk-Sources.md

Leer lassen — Cowork füllt selbst über Zeit. Du kannst aber bekannte Massenquellen vorab eintragen:
- Distribution Lists deines Unternehmens (`*@lists.firma.de`)
- Bekannte Newsletter-Absender
- Große Gruppenchats in Teams (Channel-Namen)

Behandlungs-Optionen pro Eintrag:
- **Ignorieren** — gar nicht im Briefing, direkt archiviert
- **Kernaussagen** — 1–2 Sätze im Briefing, dann archiviert
- **Volltext** — Ausnahme, wie normale Mail behandeln (z. B. Manager auch in DLs)

Allowlist nicht vergessen: Manager-Mail und Kunden-Domains eintragen, damit die nie als Bulk klassifiziert werden — auch wenn sie über DLs kommen.

### f) Kunden-MDs

Für jeden aktiven Kunden eine Datei in `data/Kunden/` anlegen. Vorlage ist `data/Kunden/_TEMPLATE.md` — kopieren und mit Kundenname benennen (z. B. `data/Kunden/Musterkunde GmbH.md`).

## 3. Mail-Regel für DOPS-Capture einrichten (NEU 1.4 — Pflicht für Mail-Capture)

Damit die Capture-Mails sauber gefiltert werden, eine Mail-Regel anlegen (Outlook, Gmail, Apple Mail — alle unterstützen das):

1. Mail-Client öffnen → Regeln/Filter → Neue Regel erstellen
2. Bedingung: **Betreff enthält bestimmte Wörter** → Wort eintragen: `DOPS-`
3. Aktion: **In Ordner verschieben** → neuen Ordner anlegen: `DOPS-Capture` (auf Inbox-Ebene)
4. Aktion zusätzlich: **Als gelesen markieren** (sonst poppt jede Capture als ungelesen auf)
5. Optional, falls dein Client Kategorien/Labels unterstützt: **Kategorie/Label zuweisen** → "DOPS-Capture" (gelb)
6. Regel auf bestehende Mails anwenden — falls du schon Tests gemacht hast
7. **Wichtig**: Regel-Name z. B. "DOPS-Capture-Filter" — leichter zu finden falls du sie später anpassen musst

Verifizieren: Schick dir selbst eine Test-Mail mit Subject `DOPS-TEST-SETUP` — sollte sofort in `DOPS-Capture` landen.

Während des Afternoon-Syncs werden verarbeitete Mails nach `DOPS-Capture/_processed/YYYY-MM-DD/` verschoben. Den Subfolder legt Cowork beim ersten Run automatisch an.

## 4. Scheduled Prompts einrichten (drei Prompts in 1.6)

**Morning-Briefing (Mo–Fr 07:00):**
1. Öffne deinen AI-Assistenten
2. Sag: "Richte mir das Morgen-Briefing aus dem Daily-Ops-Ext Skill als Scheduled Task um 07:00 Mo–Fr ein"
3. Prompt-Text aus `scheduled-prompts/morning-briefing.md` einsetzen
4. **Pflicht**: `<SKILL_PFAD>`, `<DEINE_MAIL>`, `<INTERNE_DOMAIN>`, `<PRIVAT_MAIL_1..3>`, `<FAMILIEN_NAMEN>` ersetzen

**Afternoon-Sync (Mo–Fr 15:30):**
1. Sag: "Richte mir den Afternoon-Sync aus dem Daily-Ops-Ext Skill als Scheduled Task um 15:30 Mo–Fr ein"
2. Prompt-Text aus `scheduled-prompts/afternoon-sync.md` einsetzen
3. **Pflicht**: `<SKILL_PFAD>`, `<DEINE_MAIL>`, `<PRIVAT_MAIL_1..3>` ersetzen; `<SAFE_SENDERS>` optional (leer lassen wenn nicht zutreffend)
4. Sync-Zeitpunkt anpassen falls dein Tag anders endet — sollte VOR deinem letzten Termin liegen, damit Updates aus dem letzten Meeting noch in den nächsten Morgen-Briefing einfließen können

**Wochenend-Briefing (Sa/So 07:00) — NEU 1.6:**
1. Sag: "Richte mir das Wochenend-Briefing aus dem Daily-Ops-Ext Skill als Scheduled Task um 07:00 Sa/So ein"
2. Prompt-Text aus `scheduled-prompts/weekend-briefing.md` einsetzen
3. **Pflicht**: `<SKILL_PFAD>`, `<DEINE_MAIL>`, `<PRIVAT_MAIL_1..3>`, `<FAMILIEN_NAMEN>` ersetzen
4. Strikt Privat-only — keine Beruf-Themen, keine Customer-Mails, keine Review-/Numbers-Sektionen

**Smoke-Test der Capture-Pipeline:**
- Schick dir nach dem ersten 07:00-Run eine Test-Mail: Subject `DOPS-T-XXXX-01 done`, Body `Status: done\nNotiz: Setup-Test`
- Beim 15:30-Run sollte die Test-Task in den Done-Sheet wandern und im Sync-Report auftauchen

Was die Routine täglich macht:
- liest deinen Kalender (heute + 14 Tage)
- liest neue Mails und Teams-Nachrichten seit gestern
- klassifiziert Massenmails/Newsletter/große Gruppenchats → Kernaussagen im Briefing, Volltext archiviert
- gleicht Tasks gegen Personen-Kalender ab → empfiehlt Vorziehen vor Terminen
- pflegt Kunden-Stakeholder aus Mails/Teams (Kunden-Zuordnung über Mail-Domain)
- erkennt Watchlist-Treffer und Vorlauf-Erinnerungen
- schreibt das Briefing als Markdown in `data/Briefings/YYYY-MM-DD-morning.md`
- sendet Briefing als HTML-Mail an dich mit Capture-Links

Optional: Montags läuft zusätzlich ein Backup-Schritt nach Cloud-Storage `daily-ops-ext/_backup/YYYY-MM-DD/` (8 Wochen Retention).

## 5. Datenfluss & Pflichten

### Cowork pflegt automatisch:
- Tasks-Inbox: neue Tasks aus Mails/Teams (mit Personen-Spalten gefüllt)
- Kunden-Stakeholder Sheet: neue Kontakte aus Mail/Teams/Meetings
- Kunden / Letzter Kontakt
- Highlights-Log (als "vorgeschlagen")
- Bulk-Sources.md (neue Bulk-Quellen — nach deiner Bestätigung im Briefing)
- Briefing-Datei
- Meeting-Notes (vom Afternoon-Sync)

### Du pflegst manuell:
- Kunden initial befüllen
- Interne Stakeholder bei Team-Wechseln
- Bei neuen Kunden-Kontakten: Rolle und Entscheider-Level ergänzen (Cowork markiert die Lücken)
- Stunden-Log: Cowork schlägt vor, du verifizierst und buchst extern
- Review-Cycles, wenn Vorgesetzte/r wechselt

## 6. Backup-Empfehlung

- Wöchentlich automatisch über den Backup-Schritt im Scheduled Prompt
- Manuell: einfach `data/`-Ordner kopieren

## 7. Häufige Anpassungen

- **Andere Region**: `wichtige-daten.xlsx → Ferien & Frei` mit deinen lokalen Feiertagen befüllen
- **Andere Rollen**: Im Sheet "Interne Stakeholder" beliebige Rollen eintragen — keine Vorgabe
- **Andere Sprache**: Sheet- und Sektionsüberschriften sind alle frei änderbar
- **Interne Domain**: Im Scheduled-Prompt-Text `<INTERNE_DOMAIN>` durch deine reale Domain ersetzen

## Feedback

Du kannst diese Vorlage frei für dich anpassen. Wenn du Verbesserungen hast, gerne teilen.
