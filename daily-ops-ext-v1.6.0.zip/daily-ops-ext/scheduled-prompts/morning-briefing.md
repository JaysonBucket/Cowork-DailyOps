# Scheduled Prompt — Morgen-Briefing (07:00)

**Empfohlene Konfiguration:**
- Frequenz: Wöchentlich
- Tage: Montag–Freitag
- Uhrzeit: 07:00
- Modus: `inline` (gleiche Session — Cowork lernt deinen Stil über die Zeit)

**Wichtig vor dem Einrichten:**

1. Im Prompt-Text unten den Platzhalter `<SKILL_PFAD>` durch den realen Skill-Pfad deiner Umgebung ersetzen (siehe README.md für gängige Werte).
2. `<DEINE_MAIL>` durch deine eigene Mail-Adresse ersetzen (alle `mailto:`-Links gehen an dich selbst).
3. `<INTERNE_DOMAIN>` durch deine interne Mail-Domain ersetzen (z. B. `firma.de`) — sonst werden interne Kollegen als externe Kunden-Kontakte erkannt.
4. `<PRIVAT_MAIL_1..3>` und `<FAMILIEN_NAMEN>` durch deine privaten Adressen/Namen ersetzen (NEU 1.6.0 — bestimmt Beruf/Privat-Erkennung). Felder leer lassen, wenn nicht zutreffend.
5. **Mail-Regel** für DOPS-Capture-Ordner ist eingerichtet (Anleitung in README.md).

---

```text
Erstelle mein Morgen-Briefing als zentrale Tagesvorbereitung und schicke es als HTML-Mail an mich (recipients=['me']) mit Betreff "Morgen-Briefing TT.MM. — Top 3: <Top-Task-Titel>".

Lies aus <SKILL_PFAD>/data/: Cowork-Hub.xlsx (Kunden, Interne Stakeholder, Kunden-Stakeholder, Watchlist), Tasks-Inbox.xlsx (Inbox-Sheet inkl. Capture-Code- und Bereich-Spalte), wichtige-daten.xlsx (Personen & Anlässe, Ferien & Frei), highlights.xlsx (Highlights-Log, Review-Cycles), Bulk-Sources.md (Massenmail-Klassifikation).

Sammle parallel:
- Heutigen + nächste 14 Tage Kalender (Termine + Status, Teilnehmer-Mails, kategorisierte vs. nicht-kategorisierte Events flaggen)
- Neue Mails seit gestern Abend — From + alle CC-Adressen mitlesen. WICHTIG: Mails mit `DOPS-` im Betreff ausschließen (das sind deine eigenen Captures aus dem Tag — die werden vom Afternoon-Sync verarbeitet, nicht im Morgen-Briefing)
- Neue Teams-Nachrichten in 1:1- und Gruppenchats seit gestern — Teilnehmer mitlesen
- Watchlist-Treffer in Mail/Teams (Personen, Buzzwords aus Cowork-Hub.xlsx Watchlist-Sheet)
- Vorlauf-Erinnerungen aus wichtige-daten.xlsx (heute fällige Vorlauf-Tage)
- Schulferien deiner Region(en), die heute oder in den nächsten 7 Tagen beginnen

BULK-FILTERING (Logik 0 — vor allem anderen):
Bevor du Mails/Teams in die weiteren Logiken einspeist, klassifiziere jede Nachricht:
1. Match gegen Bulk-Sources.md (Quellen-Liste): exakter Absender / Domain-Wildcard / Betreff-Pattern / Chat-Name
2. Wenn kein Match: prüfe Heuristiken (>20 Empfänger, DL-Absender wie noreply/news/digest/lists, typische Bulk-Betreffe wie "Newsletter"/"Weekly"/"Digest"/"[FYI]"/"Reminder:"/"Survey"/"Webinar", HTML mit Unsubscribe-Link, Gruppenchat >15 Teilnehmer ohne @-mention an mich, keine persönliche Anrede). Mindestens 2 Treffer → Bulk-Kandidat.
3. Allowlist aus Bulk-Sources.md hat IMMER Vorrang — Manager / Kunden-Domains nie als Bulk behandeln, auch bei DL-Versand.

Behandlung pro Nachricht:
- "Ignorieren" → gar nicht im Briefing, direkt nach Mail-Ordner "Archiv/Bulk" verschieben (Ordner anlegen falls fehlt)
- "Kernaussagen" → 1–2 Sätze in Sektion "Bulk-Kernaussagen", danach nach "Archiv/Bulk" verschieben. Volltext NICHT zitieren — nur auf explizite Rückfrage.
- "Volltext" → wie normale Mail in die Hauptlogiken einspeisen (Tasks-Erkennung, Watchlist, Highlight-Detection)
- Neue Bulk-Kandidaten ohne Eintrag in Bulk-Sources.md → in Sektion "Neue Bulk-Quellen erkannt" mit Vorschlag-Behandlung listen, NICHT archivieren bis ich bestätige.

WICHTIG: Bulk-Mails dürfen NICHT in Personen-Termin-Matching, Kunden-Stakeholder-Pflege oder Tasks-Erkennung einfließen. Sie sind explizit aus diesen Logiken ausgenommen.

PRIVAT-FILTER (Logik 0b — NEU in 1.6.0 — direkt nach Bulk-Filtering, vor allen Beruf-Logiken):
Klassifiziere jeden Termin und jede Task in eines von zwei Buckets: Beruf oder Privat.

Privat-Erkennung — JEDES dieser Kriterien reicht:
1. Kalender-Termin hat als Teilnehmer mind. eine Adresse aus: <PRIVAT_MAIL_1>, <PRIVAT_MAIL_2>, <PRIVAT_MAIL_3>
2. Kalender-Termin hat als Teilnehmer Display-Name aus: <FAMILIEN_NAMEN> (auch ohne sichtbare Mail)
3. Kalender-Termin hat Mail-Kategorie/Label "Privat" oder "Familie"
4. Eintrag in wichtige-daten.xlsx → automatisch Privat (Geburtstage, Jahrestage, Feiertage)
5. Tasks-Inbox.xlsx Spalte "Bereich" exakt = "Privat"
6. Termin-Titel enthält Privat-Indikatoren ohne Beruf-Kontext: "Geburtstag", "Hochzeitstag", "Jahrestag", "Familie", "Schule", einer der Familien-Vornamen

Behandlung Privat-Termine: KEIN Capture-Code, KEIN mailto-Link. Eigene Briefing-Sektion am Ende. NICHT in Personen-Termin-Matching mit Beruf-Tasks. NICHT in Kunden-Stakeholder-Pflege.

Behandlung Privat-Tasks (Bereich="Privat"): Capture-Code mit P-Prefix statt T (P-MMDD-NN). Eigene Briefing-Sektion "Privat-Tasks (offen)" — NICHT in Top 3. mailto-Link funktioniert wie bei Beruf-Tasks.

Behandlung neuer Tasks aus Mails/Teams: Default Bereich="Beruf". Wenn Mail von oder an eine der Privat-Adressen: Bereich="Privat".

Wochentag-Layout:
- Mo–Fr: Privat-Sektionen am Ende des Briefings, kompakt. Top 3 ist Beruf-only.
- Sa/So: dieser Prompt feuert nicht. Stattdessen läuft das separate Wochenend-Briefing (siehe scheduled-prompts/weekend-briefing.md).

PERSONEN-TERMIN-MATCHING (Logik 1 — nur Beruf):
Für jede offene Task in Tasks-Inbox.xlsx mit gefüllter Spalte "Personen (Mail)":
1. Suche im Kalender der nächsten 14 Tage nach Terminen, an denen mindestens eine dieser Personen teilnimmt
2. Wenn Treffer: schreibe den nächsten gemeinsamen Termin in Spalte "Nächster gemeinsamer Termin" (Format: "TT.MM. HH:MM Termintitel") und das Datum in "Termin-Datum"
3. Wenn der gemeinsame Termin VOR der Deadline liegt UND Status="offen": empfehle im Briefing "Vor Termin TT.MM. mit X erledigen" — eigene Sektion "Vorziehen vor Termin"
4. Wenn der gemeinsame Termin NACH der Deadline liegt: nur als Info notieren ("Folgegespräch am TT.MM. mit X")

Für neue Tasks aus Mails/Teams: trage IMMER in Spalte "Personen (Mail)" alle From + CC ein (kommatrennen) und in "Personen (Namen)" die Display-Namen. Quelle-Typ: "Mail", "Teams" oder "Meeting". Quelle-Link: Mail-ID/Chat-Link/Event-ID.

KUNDEN-STAKEHOLDER-PFLEGE (Logik 2):
Wenn in Mails/Teams/Kalenderterminen externe Personen auftauchen (Mail-Domain ist NICHT @<INTERNE_DOMAIN>), gleiche sie gegen Cowork-Hub.xlsx Sheet "Kunden-Stakeholder" ab:
1. Kunden-Zuordnung: Mail-Domain → Kunden-Sheet (Spalte "Kundenname") matchen. Wenn unklar, Kunde aus Kontext der Mail/des Termins ableiten (Betreff, andere Teilnehmer).
2. JA → "Letzter Kontakt" auf heute, "# Kontakte" um 1 erhöhen.
   NEIN → neue Zeile mit Kunde, Name, Rolle ("(Rolle ergänzen)"), Entscheider-Level ("(Level ergänzen)"), Mail, Erstkontakt-Datum=heute, -Kanal, -Anlass, Letzter Kontakt=heute, # Kontakte=1.
3. Auch in <SKILL_PFAD>/data/Kunden/<Kundenname>.md unter "## Personen / Stakeholder" eintragen.

CAPTURE-CODE-VERGABE (Logik 3 — erweitert in 1.6.0):
Vergib für jeden Eintrag im Briefing einen eindeutigen Capture-Code nach Schema:
- Beruf-Tasks: T-MMDD-NN (NN = laufende Nummer am Tag, beginnend bei 01)
- Privat-Tasks (Bereich="Privat"): P-MMDD-NN (eigene laufende Nummerierung pro Tag, beginnend bei 01 — NEU in 1.6.0)
- Meetings (Beruf): M-MMDD-XX (XX = Kurzkürzel aus Termintitel, max 6 Zeichen, Großbuchstaben, ohne Sonderzeichen — z.B. "Project Review Sync" → "PR" oder "PRSYNC")
- Privat-Termine: KEIN Code (siehe Logik 0b)
- Bei Tasks: schreibe den Code in Spalte "Capture-Code" der Tasks-Inbox.xlsx (nicht überschreiben falls schon gefüllt — bestehende Codes bleiben über mehrere Tage stabil!)
- Bei Meetings: Code wird nur fürs Briefing generiert, nicht persistiert (Meetings haben Event-IDs)

MAILTO-LINK-GENERIERUNG (Logik 4 — NEU in 1.4):
Für jeden Capture-Code im Briefing erzeuge einen mailto:-Link mit URL-encoded Subject und Body. Empfänger immer <DEINE_MAIL>.

Schema für Tasks:
  Subject: "DOPS-<CAPTURE-CODE> <Task-Titel>"
  Body:
    Status: [done | progress | paused | reschedule]

    Notiz:

    ---
    Kontext: <Task-Titel>, fällig <TT.MM.>, Personen: <Personen-Namen>, Quelle: <Quelle-Typ>

Schema für Meetings:
  Subject: "DOPS-<CAPTURE-CODE> <Termintitel>"
  Body:
    Notizen:

    Neue Stakeholder: (Name <Mail>, Rolle)
    Folge-Tasks: (Beschreibung — Cowork legt automatisch in Inbox an)

    ---
    Kontext: <Termintitel>, <TT.MM. HH:MM>-<HH:MM>, Teilnehmer: <Teilnehmer-Liste>

Schema für Adhoc-Task:
  Subject: "DOPS-NEW <kurze-beschreibung>"
  Body:
    Beschreibung:
    Fällig:
    Personen:
    Bereich: [Beruf | Privat]
    Priorität: [P1 | P2 | P3]

URL-Encoding: Leerzeichen → %20, Newline → %0A, Doppelpunkt → %3A, Pipe → %7C, eckige Klammern → %5B/%5D, Komma → %2C, Bindestrich bleibt als - (nicht escapen).

LÄNGEN-LIMIT (kritisch — sonst öffnen Mail-Clients/Browser den Link nicht):
Mail-Clients akzeptieren mailto-URLs bis ~2000 Zeichen zuverlässig. Berechne pro Eintrag die Gesamt-URL-Länge VOR dem Einfügen ins HTML.

Stufe 1 (Standard): Voller Body wie oben definiert. URL-Länge prüfen.

WICHTIG: Hinweise IMMER NACH dem `---`-Separator setzen, niemals davor — der Afternoon-Sync-Parser ignoriert alles nach `---` als Kontext-Block. Wenn Hinweise vor `---` stehen, würden sie als User-Eingabe interpretiert und den Status-Parser stören.

Stufe 2 (URL > 1800 Zeichen): Kontext-Block nach `---` kürzen — nur Titel + Datum behalten, Personen-/Teilnehmer-Liste und Quelle weglassen. Direkt darunter (immer noch nach `---`) Hinweis-Zeile: "Vollständiger Kontext im Tagesbriefing: <SKILL_PFAD>/data/Briefings/YYYY-MM-DD-morning.md".

Stufe 3 (immer noch > 1900 Zeichen): Kontext-Block komplett weglassen. Body reduziert sich auf:
- Tasks: "Status:\n\nNotiz:\n\n---\nKontext gekürzt — siehe Tagesbriefing YYYY-MM-DD-morning.md"
- Meetings: "Notizen:\n\nNeue Stakeholder:\nFolge-Tasks:\n\n---\nKontext gekürzt — siehe Tagesbriefing YYYY-MM-DD-morning.md"
Zusätzlich im Briefing-HTML neben dem Eintrag das Symbol "📎 Kontext gekürzt" anzeigen — damit du beim Lesen des Briefings schon weißt, dass die Capture-Mail nicht alles enthält.

Im NORMALFALL (>95% der Tasks/Meetings) reicht Stufe 1.

BRIEFING-MAIL-AUFBAU (HTML, mobile-tauglich):
Die Mail soll auf Mobile gut lesbar sein — kurze Absätze, keine breiten Tabellen, klare Buttons.

Struktur:
1. Anrede + Datum
2. Top 3 für heute (P1-Tasks aus Inbox) — pro Eintrag: Titel, Code in Klammern, mailto-Link "Update senden"
3. **Vorziehen vor Termin** — pro Eintrag: "T-XXXX-NN — Task XYZ vor Termin TT.MM. mit Person erledigen" + mailto-Link
4. Heute Termine — pro Eintrag: "M-XXXX-XX — Zeit Titel, Teilnehmer" + mailto-Link "Notizen senden"
5. Vorlauf-Alerts (persönliche Daten aus wichtige-daten.xlsx)
6. Watchlist-Treffer seit gestern
7. Neue Tasks seit gestern (aus Mails/Teams identifiziert) — bereits in Inbox eingetragen MIT Personen-Spalten und Capture-Code
8. **Neue Kunden-Kontakte** (heute neu angelegt — Rolle/Level offen)
9. Highlight-Detection (positive Customer-Mails, abgeschlossene Milestones gestern)
10. **Bulk-Kernaussagen** (Massenmails/Newsletter/große Gruppenchats — je 1–2 Sätze, archiviert nach "Archiv/Bulk")
11. **Neue Bulk-Quellen erkannt** (Kandidaten zur Aufnahme in Bulk-Sources.md mit Vorschlag-Behandlung — warten auf Bestätigung)
12. Anstehende Ferien/Frei deiner Region
13. **Privat-Termine heute & nächste 7 Tage** (kompakt, am Ende — NEU 1.6.0)
14. **Privat-Tasks (offen)** (Bereich="Privat" aus Tasks-Inbox.xlsx, mit P-Codes — NEU 1.6.0)

Am Ende der Mail einen **Cheatsheet-Block**:

  Capture-Cheatsheet:
  - Klick auf "Update senden" / "Notizen senden" — Mail öffnet vorbefüllt
  - Status-Wort in 1. Zeile (done | progress | paused | reschedule)
  - Notiz darunter, Rest unverändert lassen
  - Adhoc-Task: neue Mail, Subject "DOPS-NEW kurze-beschreibung"
  - Kommt um 15:30 in den Daily-Sync

Lege parallel die Briefing-Datei <SKILL_PFAD>/data/Briefings/YYYY-MM-DD-morning.md ab (gleicher Inhalt wie Mail, ohne mailto-Links). Codes-Map am Ende der Datei: für den Afternoon-Sync MUSS eine Tabelle "Capture-Code → Task-ID / Event-ID" bestehen.

Trage neue Tasks in die Inbox-Sheet ein. Tracke erkannte Highlights als "vorgeschlagen". Aktualisiere Kunden-Sheet "Letzter Kontakt". Bei bestätigten Bulk-Quellen Eintrag in Bulk-Sources.md ergänzen.

MONTAGS ZUSÄTZLICH (Backup-Schritt vor dem Briefing): Kopiere alle 4 xlsx-Dateien plus den Kunden/-Ordner in Cloud-Backup-Ordner "daily-ops-ext/_backup/YYYY-MM-DD/". Behalte die letzten 8 Wochen-Backups, lösche ältere.

Sprache: Deutsch (oder anpassen). Pragmatisch, kein Beschönigen. Bei fehlenden Daten/Stakeholdern aktiv flaggen statt Lücken zu kaschieren.
```

---

## Anpassungen

- **`<SKILL_PFAD>`**: vor dem ersten Run komplett ersetzen (typisch: dein realer Skill-Pfad in der Cowork-Umgebung)
- **`<DEINE_MAIL>`**: deine eigene Mail-Adresse für die mailto-Links
- **`<INTERNE_DOMAIN>`**: deine interne Mail-Domain (z. B. `firma.de`) — sonst werden interne Kollegen als externe Kunden erkannt
- **Sprache, Region, Backup-Ziel**: wie in vorherigen Versionen
