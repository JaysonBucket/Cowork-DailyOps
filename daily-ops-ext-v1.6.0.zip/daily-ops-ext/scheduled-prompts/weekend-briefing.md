# Scheduled Prompt — Wochenend-Briefing (Sa/So 07:00)

**Empfohlene Konfiguration:**
- Frequenz: Wöchentlich
- Tage: Samstag, Sonntag
- Uhrzeit: 07:00
- Modus: `inline`

**Wichtig vor dem Einrichten:**

1. Im Prompt-Text unten den Platzhalter `<SKILL_PFAD>` durch den realen Skill-Pfad ersetzen.
2. `<DEINE_MAIL>` durch deine eigene Mail-Adresse ersetzen.
3. `<PRIVAT_MAIL_1>`, `<PRIVAT_MAIL_2>`, `<PRIVAT_MAIL_3>` durch deine privaten Mail-Adressen ersetzen (z. B. private Mail-Adresse, Partner-Adresse). Felder leer lassen, wenn weniger als 3 Adressen.
4. `<FAMILIEN_NAMEN>` durch eine kommagetrennte Liste der Display-Namen aus deinem privaten Umfeld ersetzen (z. B. "Partnervorname,Kind-1,Kind-2").
5. `<INTERNE_DOMAIN>` durch deine berufliche Mail-Domain ersetzen (z. B. `firma.de` — wird im Sanity-Check verwendet).

---

```text
Erstelle mein Wochenend-Briefing als zentrale Privat-Tagesvorbereitung und schicke es als HTML-Mail an mich (recipients=['me']) mit Betreff "Wochenend-Briefing TT.MM. — Privat".

GRUND-REGEL (kritisch): Im Zweifel AUSSCHLIESSEN. Lieber einen privaten Eintrag verpassen als einen Beruf-Eintrag durchlassen. Dieses Briefing ist explizit Privat-only.

Lies aus <SKILL_PFAD>/data/: Tasks-Inbox.xlsx (NUR Zeilen mit Bereich='Privat' — Spalte 17. Leere Bereich-Zelle oder Bereich='Beruf' → AUSSCHLIESSEN, kein Default-Privat), wichtige-daten.xlsx (Personen & Anlässe — die sind per Definition Privat; Ferien & Frei — deine Region).

Sammle parallel:
- Heutige + nächste 7 Tage Kalender — STRIKT NUR Privat-Termine (siehe PRIVAT-FILTER unten). Beruf-Termine werden ignoriert.
- Vorlauf-Erinnerungen aus wichtige-daten.xlsx Personen & Anlässe (heute fällige Vorlauf-Tage)
- Schulferien deiner Region(en), die heute oder in den nächsten 7 Tagen beginnen

PRIVAT-FILTER (kritisch — bestimmt was im Briefing landet):
Ein Termin gilt nur dann als Privat, wenn MIND. EINES dieser harten Kriterien zutrifft:
1. Teilnehmer enthält mind. eine Adresse aus: <PRIVAT_MAIL_1>, <PRIVAT_MAIL_2>, <PRIVAT_MAIL_3>
2. Teilnehmer-Display-Name ist einer aus: <FAMILIEN_NAMEN> (auch ohne sichtbare Mail)
3. Termin hat Mail-Kategorie/Label "Privat" oder "Familie"
4. Termin steht in wichtige-daten.xlsx (Geburtstag, Jahrestag etc.)
5. Termin-Titel enthält Privat-Indikatoren ohne Beruf-Kontext: "Geburtstag", "Hochzeitstag", "Jahrestag", "Familie", "Schule", einer der Familien-Vornamen ohne Firma/Kunde-Kontext

Wenn ein Termin zwischen Beruf und Privat unklar ist (z. B. Geschäftsreise mit Familie, oder beruflicher Kollege als Freund) → AUSSCHLIESSEN, nicht raten. Das Wochenend-Briefing ist ein Privat-Briefing — Falsch-Positives sind teuer.

Ein Task gilt nur dann als Privat, wenn:
- Spalte "Bereich" exakt "Privat" enthält. Leer = AUSSCHLIESSEN.

BRIEFING-MAIL-AUFBAU (HTML, mobile-tauglich):

Struktur (Sa/So Layout — Privat prominent oben, kompakt):
1. Anrede + Datum + Wochentag
2. **Heute** (Termine + heute fällige Tasks aus Tasks-Inbox.xlsx mit Bereich='Privat')
3. **Diese Woche** (Termine + Tasks der nächsten 7 Tage)
4. **Vorlauf-Erinnerungen** (heute fällige Erinnerungen aus wichtige-daten.xlsx — Geburtstage, Jahrestage)
5. **Anstehende Ferien/Frei** (deine Region, nächste 7 Tage)
6. **Privat-Tasks (offen)** — STRIKT NUR Tasks-Inbox-Einträge mit Bereich='Privat' UND Status='offen'. Beruf-Tasks (Bereich='Beruf' oder leer) sind hier ausgeschlossen, auch wenn der Titel privat klingt.

Für Tasks: Capture-Code mit P-Prefix (P-MMDD-NN) statt T. Mailto-Link wie bei Beruf-Tasks. Rest gleicher Aufbau.

SANITY-CHECK vor Versand:
Scanne die fertige Mail auf Beruf-Triggerwörter: "Workshop", "Sync", "Review", "Customer", "Kunde", "Vertragsverlängerung", Kunden-Namen aus Cowork-Hub.xlsx, @<INTERNE_DOMAIN>-Adressen, Mail-Domains von Kunden. Wenn ein Treffer im Briefing steht → STOPP, Eintrag rausnehmen, neu zusammensetzen. Lieber leer und kurz als versehentlich Beruf drin.

Cheatsheet-Block am Ende:

  Privat-Capture-Cheatsheet:
  - P-MMDD-NN Codes funktionieren genauso wie T-Codes
  - Status: done | progress | paused | reschedule
  - Adhoc-Privat-Task: Subject "DOPS-NEW <beschreibung>", im Body "Bereich: Privat"

Lege parallel die Briefing-Datei <SKILL_PFAD>/data/Briefings/YYYY-MM-DD-weekend.md ab.

Sprache: Deutsch. Pragmatisch, kurz. Bei fehlenden Privat-Daten lieber ein knappes Briefing schicken als Beruf-Lücken zu füllen.
```

---

## Anpassungen

- **`<SKILL_PFAD>`**, **`<DEINE_MAIL>`**: wie in den anderen Prompts
- **`<PRIVAT_MAIL_1..3>`**: deine privaten Mail-Adressen — bestimmt, welche Termine als privat erkannt werden
- **`<FAMILIEN_NAMEN>`**: kommagetrennte Display-Namen aus deinem privaten Umfeld (Partner, Kinder etc.)
- **`<INTERNE_DOMAIN>`**: deine Beruf-Domain für den Sanity-Check
- **Sanity-Check Triggerwörter**: an deine Branche anpassen — bei reinen Privatpersonen ggf. komplett weglassen
