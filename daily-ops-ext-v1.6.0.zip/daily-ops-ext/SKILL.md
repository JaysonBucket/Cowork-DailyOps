---
name: daily-ops-ext
version: 1.6.0
description: |
  Persönliches Daily-Operations-System für customer-facing Rollen (Account Manager, Consultants,
  Solution Architects, Projektleiter, Customer Success). Erfasst Tasks, Kunden, Stakeholder,
  Projekte, Stunden, Highlights in einem strukturierten Hub. Verbindet Tasks mit Personen →
  Kalender und schlägt im Morgen-Briefing das Vorziehen vor gemeinsamen Terminen vor. Pflegt
  Kunden-Stakeholder automatisch aus Mail/Teams/Meetings. Filtert Massenmails und große
  Gruppenchats raus.

  Day-Cycle: 07:00 Morgen-Briefing per Mail mit Capture-Codes und mailto-Links für jede Task
  und jeden Termin. Tag über schickt der User Status-Updates und Meeting-Notizen per Mail
  an sich selbst (Mail-Regel filtert auf "DOPS-" im Betreff). 15:30 Afternoon-Sync liest
  alle Captures, aktualisiert Tasks-Inbox/Kunden-MDs, schickt Sync-Report.

  Primäre Trigger (DOPS-Prefix Kurz-Befehle, kollidieren nicht mit built-in daily-briefing):
  "DOPS start", "DOPS morgen", "DOPS briefing" (Morgen-Briefing); "DOPS sync", "DOPS abschluss"
  (Afternoon-Sync); "DOPS check" (Status ohne Mail); "DOPS review" (Review-Vorbereitung);
  "DOPS pflege" (Kunden-Stakeholder ad-hoc).

  Sekundäre Trigger (distinktive natürliche Phrasen): "Daily-Ops Briefing", "Daily-Ops Sync",
  "Vorziehen vor Termin", "Stakeholder bei Kunde X", "Review-Vorbereitung", "Highlights-Log",
  "wer ist nächste Woche bei welchem Kunden".

  Do NOT use for: generische Kalender-Übersicht ohne Kundenkontext (use built-in
  daily-briefing/calendar-management); Meeting-Recaps eines einzelnen Termins
  (use meeting-intel); allgemeine E-Mail-Triage ohne Kunden-Kontext. Generische Phrasen wie
  "Morgen-Briefing", "Tagesüberblick", "morning briefing" werden bewusst NICHT mehr getriggert
  (Kollisionsgefahr mit built-in daily-briefing) — explizites "DOPS"-Prefix nutzen.
---

# Daily-Ops Ext Skill v1.6.0

> **Generische Variante** ohne unternehmens-spezifische Begriffe. Funktional gleichwertig zur internen `daily-ops-ms`-Variante (gleicher Versions-Stand v1.6.0) — aber portabel über Branchen und Firmen hinweg.

> Aktuelle Version: **1.6.0** — siehe [CHANGELOG.md](CHANGELOG.md) für Änderungen.

Ein persönliches Operations-System für Rollen, die viele Kunden, Projekte und Stakeholder gleichzeitig managen. Vorlage zum Importieren — alle Daten generisch, du befüllst mit deiner Welt.

## Was er löst

- **Tasks ohne Kontext-Verlust** — pro Aufgabe wird Quelle (Mail/Teams/Meeting) UND involvierte Personen festgehalten
- **Vorziehen vor Termin** — wenn eine offene Task Personen betrifft, mit denen du bald einen Termin hast, schlägt Cowork das Vorziehen vor
- **Kunden-Stakeholder wachsen automatisch** — neue Kontakte aus Mails/Teams werden in Hub + pro-Kunde-MD eingetragen, mit Lücken-Markierung für Rolle und Entscheider-Level
- **Review-Vorbereitung** — Highlights-Log, Numbers-Tracker, Review-Cycles als zentrale Sammlung
- **Wichtige private Daten** — Geburtstage, Jahrestage, Schulferien deiner Region
- **Bulk-Filter** — Massenmails, Newsletter und große Gruppenchats werden erkannt, im Briefing nur als Kernaussagen aufbereitet und automatisch archiviert
- **Day-Cycle mit Mail-Capture (NEU 1.4)** — 07:00 Briefing-Mail mit klickbaren Capture-Links, Tag über schickst du Updates per Mail an dich selbst, 15:30 arbeitet Cowork alles ein
- **Privat/Beruf-Trennung (NEU 1.6)** — eigener Bereich-Filter, P-MMDD-NN Codes für Privat-Tasks, separates Wochenend-Briefing nur für Privates (Sa/So 07:00). Im Mo–Fr Briefing landen Privat-Termine kompakt am Ende, Top-3 bleibt Beruf-only.
- **Sicherheits-Filter für Captures (NEU 1.6)** — Afternoon-Sync verarbeitet nur DOPS-Mails von vertrauenswürdigen Absendern (eigene Adresse, Privat-Adressen, optionale Safe-Senders-Liste). Fremde Captures werden nach `_rejected/` verschoben und im Sync-Report geflaggt — kein Risiko durch von außen eingespielte Tasks/Stakeholder.

## Datei-Struktur

```
data/
├── Cowork-Hub.xlsx          # 7 Sheets: Kunden, Interne Stakeholder, Kunden-Stakeholder,
│                             #          Partner, Projekte & Milestones, Stunden-Log, Watchlist
├── Tasks-Inbox.xlsx          # 3 Sheets: Inbox (Personen-Termin-Matching + Capture-Code + Bereich),
│                             #          Done (Capture-Code + Bereich), Backlog
├── wichtige-daten.xlsx       # 2 Sheets: Personen & Anlässe, Ferien & Frei
├── highlights.xlsx           # 3 Sheets: Highlights-Log, Review-Cycles, Numbers-Tracker
├── Bulk-Sources.md           # Massenmail-Klassifikation (wächst automatisch)
├── Kunden/                   # eine MD pro Kunde — Stakeholder, Verlauf, Notizen
├── Meeting-Notes/            # YYYY-MM-DD-<CODE>.md je Termin (NEU 1.4 — vom Afternoon-Sync)
└── Briefings/                # Morning/Afternoon-Files täglich
```

## Day-Cycle (NEU in 1.4)

```
  07:00 ───────────► Tag über ───────────► 15:30
  Briefing-Mail      Mail-Capture          Afternoon-Sync
  + Capture-Codes    DOPS--Subject         + Sync-Report-Mail
  + mailto-Links     → Mail-Regel          + Tasks/Kunden update
                     → DOPS-Capture-Ordner
```

**Capture-Code-Schema:**
- `T-MMDD-NN` — Beruf-Task-Code (laufende Nummer am Tag), bleibt mehrere Tage stabil
- `P-MMDD-NN` — Privat-Task-Code (NEU 1.6 — eigene Nummerierung pro Tag)
- `M-MMDD-XX` — Meeting-Code (XX = Kürzel aus Termintitel)
- `NEW` — Adhoc-Task

**Mail-Subject-Format** für Captures:
```
DOPS-T-0504-01 Vertragsverlängerung Kunde X    → Task-Update
DOPS-M-0504-PR Project Review Sync             → Meeting-Notiz
DOPS-NEW Folgeauftrag Musterkunde GmbH         → Adhoc-Task
```

Mail-Regel (Outlook/Gmail/etc.) matcht auf `Subject contains DOPS-` → Move to `DOPS-Capture`.

**Mail-Body-Format** (vom mailto-Link vorbefüllt):

Für Tasks:
```
Status: [done | progress | paused | reschedule]

Notiz:

---
Kontext: <vom Briefing generiert — nicht löschen>
```

Für Meetings:
```
Notizen:

Neue Stakeholder: (Name <Mail>, Rolle)
Folge-Tasks:

---
Kontext: <vom Briefing generiert>
```

## Setup

1. **Skill importieren** — Skill-Verzeichnis nach den Konventionen deiner Cowork-Umgebung anlegen (siehe README.md)
2. **Initial befüllen** — Kunden, Interne Stakeholder, Watchlist, wichtige-daten, Review-Cycles
3. **Pro Kunde** eine MD-Datei in `data/Kunden/` anlegen
4. **Mail-Regel einrichten** für `DOPS-`-Capture (siehe README.md, neuer Schritt für 1.4)
5. **Drei Scheduled Prompts**:
   - Mo–Fr 07:00 — Morning-Briefing (`scheduled-prompts/morning-briefing.md`)
   - Mo–Fr 15:30 — Afternoon-Sync (`scheduled-prompts/afternoon-sync.md`)
   - Sa/So 07:00 — Wochenend-Briefing (`scheduled-prompts/weekend-briefing.md` — NEU 1.6)

In allen Prompts `<SKILL_PFAD>`, `<DEINE_MAIL>` und `<INTERNE_DOMAIN>` einmalig ersetzen. Für die Privat-Filter (NEU 1.6) zusätzlich `<PRIVAT_MAIL_1..3>` und `<FAMILIEN_NAMEN>` befüllen. Für den Sicherheits-Filter im Afternoon-Sync (NEU 1.6) optional `<SAFE_SENDERS>` mit zusätzlichen vertrauenswürdigen Absendern.

## Wann diesen Skill nutzen

**Befehls-Cheatsheet (DOPS-Prefix — empfohlen, kollidiert nicht mit built-in daily-briefing):**

| Befehl | Tut was |
|--------|---------|
| `DOPS start` / `DOPS morgen` / `DOPS briefing` | Morgen-Briefing manuell anstoßen |
| `DOPS sync` / `DOPS abschluss` | Afternoon-Sync manuell anstoßen |
| `DOPS check` | Status-Check ohne Mail (was steht offen? was kommt heute?) |
| `DOPS review` | Review-Vorbereitung — Highlights + Numbers seit letztem Cycle |
| `DOPS pflege` | Kunden-Stakeholder ad-hoc pflegen (Lücken-Liste) |

**Distinktive natürliche Phrasen (funktionieren auch):**

- "Daily-Ops Briefing" / "Daily-Ops Sync"
- "Welche Tasks sollte ich vor Termin TT.MM. mit X vorziehen?"
- "Wer sind die Stakeholder bei [Kunde]?"
- "Review-Vorbereitung" / "Highlights-Log seit letztem Review"

## Wann NICHT diesen Skill nutzen

- **Generische Tagesübersicht ohne Kunden-Kontext** → built-in `daily-briefing` Skill ist leichtgewichtiger. Wenn du nur „morning briefing" / „Tagesüberblick" sagst, springt absichtlich der built-in Skill an — Daily-Ops Ext feuert nur auf `DOPS`-Prefix oder „Daily-Ops".
- **Einzelmeeting-Recap oder -Vorbereitung** → `meeting-intel` Skill greift gezielter zu
- **Reine Kalender-Pflege** (Termine umlegen, absagen) → `calendar-management` / `schedule-meeting` Skills
- **Adhoc-Mail-Triage ohne Kunden-Bezug** → direkt mit Mail-Tools arbeiten

## Wie Cowork den Skill nutzt

| Anfrage | Geladen |
|---------|---------|
| Morgen-Briefing (volle Routine) | alle 4 xlsx + alle Kunden-MDs + Bulk-Sources |
| Afternoon-Sync | Tasks-Inbox + Codes-Map aus Briefing + Capture-Mails + Kunden-MDs |
| "Vorziehen vor Termin?" | Tasks-Inbox + Kalender |
| "Stakeholder bei Kunde X?" | Cowork-Hub + `Kunden/<Kunde>.md` |
| "Review-Vorbereitung" | highlights.xlsx + letzte 4 Briefings |

## Anpassungen

- **Region**: Trag deine Feiertage und Schulferien in `wichtige-daten.xlsx` ein
- **Rollen**: Im Sheet "Interne Stakeholder" sind Rollen frei wählbar — passend zu deinem Setup (z. B. Account Manager, Solution Architect, Projektleitung, Customer Success Manager)
- **Sprache**: Vorlagen sind auf Deutsch — Sektionsüberschriften kannst du frei umbenennen
- **Interne Domain**: Im Scheduled-Prompt-Text `<INTERNE_DOMAIN>` durch deine reale Domain ersetzen, damit "externe vs. interne Personen" richtig erkannt werden
- **Sync-Zeiten**: 07:00 / 15:30 sind Default. Wenn dein Tag anders strukturiert ist, im Scheduled-Prompt-Setup anpassen
