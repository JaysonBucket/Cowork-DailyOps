# Changelog

Alle relevanten Änderungen am Daily-Ops Ext Skill. Format: [Semantic Versioning](https://semver.org/lang/de/) — MAJOR.MINOR.PATCH.

- **MAJOR** — Breaking Changes (Excel-Schema-Brüche, inkompatible Briefing-Logik). Manuelle Migration nötig.
- **MINOR** — Neue Features, abwärtskompatibel. Bestehende Daten bleiben unverändert nutzbar.
- **PATCH** — Bugfixes, Doku-Ergänzungen, kosmetische Korrekturen.

> **Hinweis zum Versions-Sprung von 1.0.0 → 1.4.1**: Die ext-Variante wird auf den gleichen Versions-Stand wie die interne `daily-ops-ms` (1.4.1) gezogen, damit beide Varianten konsistent sind. Die unter [1.1.0]–[1.4.1] beschriebenen Features waren in `daily-ops-ms` schon umgesetzt und werden hier in einem Schritt nach ext portiert (ohne MS-Spezifika).

---

## [1.6.0] — 2026-05-02

### Neu

- **Privat/Beruf-Trennung** (Logik 0b im Morning-Briefing, eigener Prompt für Wochenende):
  - Tasks-Inbox.xlsx Inbox-Sheet bekommt 17. Spalte **Bereich** (Dropdown: Beruf | Privat). Done-Sheet 10. Spalte ebenfalls Bereich. Alte Zeilen ohne Wert werden als Beruf behandelt.
  - **P-MMDD-NN Capture-Codes** für Privat-Tasks — eigene laufende Nummerierung pro Tag, parallel zu T-Codes.
  - **6 harte Privat-Erkennungs-Kriterien** im Morning-Briefing: Privat-Mail-Adressen, Familien-Namen, Mail-Kategorie "Privat"/"Familie", Eintrag in wichtige-daten.xlsx, Bereich="Privat", oder Privat-Indikatoren im Termintitel.
  - **Mo–Fr Layout**: Privat-Sektionen am Ende, kompakt. Top-3 bleibt Beruf-only.
  - **Wochenend-Briefing** als dritter Scheduled Prompt (`scheduled-prompts/weekend-briefing.md`, Sa/So 07:00) — strikt Privat-only, mit Sanity-Check auf Beruf-Triggerwörter (Workshop, Sync, Review, Customer, Kunden-Domains, …) und Grund-Regel "Im Zweifel AUSSCHLIESSEN".
- **Sicherheits-Filter im Afternoon-Sync** (SCHRITT 0):
  - Whitelist-basiertes Allowlist-Matching auf From-Adresse: `<DEINE_MAIL>`, `<PRIVAT_MAIL_1..3>`, `<SAFE_SENDERS>` (optional).
  - Captures von Absendern ausserhalb der Allowlist werden NICHT verarbeitet, sondern nach `DOPS-Capture/_rejected/YYYY-MM-DD/` verschoben und im Sync-Report unter "Klärungsbedarf" gemeldet.
  - Verhindert Injection-Risiko, falls jemand DOPS-formatierte Mails an dich schickt — Tasks/Stakeholder/Meeting-Notes werden nur aus eigener Quelle eingearbeitet.
  - Konservativer Default: bei unklarem Header → ablehnen, nicht raten.
- **Adhoc-Task-Schema erweitert** um Bereich-Feld: `Bereich: [Beruf | Privat]` im Body. Default Beruf, wenn leer oder ungültig. Afternoon-Sync übernimmt das Feld in die neue Inbox-Zeile.

### Geändert

- **Morning-Briefing-Struktur**: zwei neue Sektionen 13 (Privat-Termine heute & nächste 7 Tage) und 14 (Privat-Tasks offen) am Ende, kompakt.
- **Capture-Code-Vergabe (Logik 3)**: P-Prefix für Privat ergänzt, Privat-Termine bekommen explizit KEINEN Code (siehe Logik 0b).
- **Personen-Termin-Matching (Logik 1)** wird nur noch auf Beruf-Tasks angewendet — Privat-Tasks matchen nicht gegen Beruf-Kalender.

### Migration von 1.5.x

- **Tasks-Inbox.xlsx**: bei bestehenden Daten manuell die Bereich-Spalte (Spalte 17 Inbox / Spalte 10 Done) ergänzen oder Vorlage neu importieren. Leere Bereich-Zelle wird als Beruf interpretiert — bestehende Tasks bleiben funktional.
- **Drei Scheduled Prompts setzen statt zwei**: Morning-Briefing UND Afternoon-Sync neu laden (mit den 1.6.0-Texten), zusätzlich Wochenend-Briefing für Sa/So 07:00 anlegen.
- **Pflicht**: in allen drei Prompts `<PRIVAT_MAIL_1..3>` und `<FAMILIEN_NAMEN>` befüllen, sonst greift der Privat-Filter nicht.
- **Pflicht für Sicherheits-Loop**: im Afternoon-Sync `<SAFE_SENDERS>` einmal anschauen — leer lassen, wenn nur eigene + Privat-Adressen reichen.
- **Keine Excel-Schema-Brüche** im Cowork-Hub, wichtige-daten, highlights — nur Tasks-Inbox bekommt eine zusätzliche Spalte.

---

## [1.5.0] — 2026-05-02

### Geändert

- **Trigger-Schema umgebaut auf `DOPS`-Prefix-Namespace**: Daily-Ops Ext und der built-in `daily-briefing`-Skill hatten kollidierende Trigger ("Morgen-Briefing", "Tagesüberblick", "morning briefing", "daily ops") — der built-in Skill sprang oft an, wenn der User eigentlich Daily-Ops wollte (oder umgekehrt). Lösung: `DOPS`-Prefix als Namespace für alle primären Befehle. Knüpft am bereits etablierten `DOPS-` aus dem Capture-Subject an — ein Mental-Model, ein Prefix.

### Neu

- **DOPS-Prefix Befehls-Set** für manuelles Anstoßen:
  - `DOPS start` / `DOPS morgen` / `DOPS briefing` → Morgen-Briefing
  - `DOPS sync` / `DOPS abschluss` → Afternoon-Sync
  - `DOPS check` → Status-Check ohne Mail (was steht offen? was kommt heute?)
  - `DOPS review` → Review-Vorbereitung (Highlights + Numbers seit letztem Cycle)
  - `DOPS pflege` → Kunden-Stakeholder ad-hoc pflegen
- **Sekundäre Trigger** (distinktive natürliche Phrasen — bleiben aktiv): „Daily-Ops Briefing", „Daily-Ops Sync", „Vorziehen vor Termin", „Stakeholder bei Kunde X", „Review-Vorbereitung", „Highlights-Log".
- **Befehls-Cheatsheet** als Tabelle in SKILL.md („Wann diesen Skill nutzen") und in README.md („Was ist neu in 1.5.0") — User sieht auf einen Blick, was er sagen kann.

### Entfernt aus Trigger-Liste

Folgende generische Phrasen feuern absichtlich NICHT mehr Daily-Ops Ext, sondern den built-in `daily-briefing`-Skill:

- „Morgen-Briefing" (allein, ohne „Daily-Ops" davor)
- „Tagesüberblick"
- „morning briefing"
- „neue Tasks für mich"
- „daily ops" (klein geschrieben, ohne Kontext)

User-Wert: Wenn jemand nur einen schnellen Tagesüberblick will, kriegt er den leichtgewichtigen built-in Skill. Wenn er die volle Daily-Ops-Routine will, sagt er `DOPS start` oder „Daily-Ops Briefing". Klare Disambiguation.

### Versions-Sync mit ms-Variante

- ext und ms ziehen parallel auf 1.5.0 — beide Varianten haben das gleiche Trigger-Schema mit angepasstem Befehls-Set (ext: `DOPS review` statt `DOPS connect`/`DOPS renewal`).

### Migration von 1.4.x

- **Keine Excel-Änderungen**, keine Datenverluste.
- **Keine Scheduled-Prompt-Änderungen**: 07:00 Morning-Briefing und 15:30 Afternoon-Sync laufen unverändert. Das Trigger-Redesign betrifft nur manuelle Anfragen an den Skill.
- **Pflicht**: SKILL.md neu laden lassen (oder Skill neu importieren), damit der Skill-Loader die neue `description` mit dem DOPS-Prefix-Trigger-Set zieht. Sonst feuert weiter die alte 1.4.1-Trigger-Liste.
- **Empfohlen**: Cheatsheet in der README.md kurz anschauen — die neuen Befehle sind in 30 Sekunden gemerkt.

---

## [1.4.1] — 2026-05-02

### Geändert

- **Subject-Identifier auf maximale Mail-Client-Kompatibilität umgestellt**: `DOPS-` statt `DOPS#`. Der Hash war in einigen Mail-Tokenizern (neues Outlook für Web/Mac) nicht zuverlässig als Wort-Bestandteil erkannt — der Bindestrich wird in allen Clients (Outlook Classic Desktop, neues Outlook, Web, Mac, Mobile, Gmail, Apple Mail) konsistent als Teil des Subject-Worts behandelt. Mail-Regel matcht jetzt auf "Subject contains DOPS-".
- **URL-Encoding für `#` entfällt**: Die `%23`-Encoding-Anweisung in der mailto-Link-Logik entfällt mitsamt dem Hash-spezifischen Warnhinweis. Bindestrich braucht kein Encoding und ist robuster.

### Neu

- **Mailto-Längen-Limit aktiv eingehalten** (3-stufige Logik):
  - Stufe 1 (Standard): voller Kontext-Block im Body.
  - Stufe 2 (URL > 1800 Zeichen): Kontext-Block reduziert auf Titel + Datum, Hinweis im Body „Vollständiger Kontext im Tagesbriefing".
  - Stufe 3 (URL > 1900 Zeichen): Kontext-Block weggelassen, im Briefing-HTML 📎-Symbol neben dem Eintrag.
  - Damit gehen auch Tasks mit langer Personen-Liste oder Meetings mit großer Teilnehmer-Liste zuverlässig durch — Mail-Clients akzeptieren keine mailto-URLs jenseits ~2000 Zeichen.

### Versions-Sync mit ms-Variante

- Die ext-Variante zieht in einem Schritt von 1.0.0 auf 1.4.1 nach. Die in 1.1, 1.2, 1.3 und 1.4 beschriebenen Features sind in der ext jetzt vollständig enthalten — siehe untenstehende historische Einträge für Details.

### Migration von 1.0.x

- **Pflicht**: Mail-Regel einrichten — „Subject contains" auf `DOPS-` setzen, Move zu Ordner `DOPS-Capture` (siehe README.md Schritt 3).
- **Pflicht**: Beide Scheduled Prompts neu setzen mit den 1.4.1-Texten aus `scheduled-prompts/`. In beiden Prompts `<SKILL_PFAD>`, `<DEINE_MAIL>` UND `<INTERNE_DOMAIN>` ersetzen.
- **Excel-Update**: Tasks-Inbox.xlsx hat jetzt zusätzliche Spalte "Capture-Code" (Inbox + Done). Bestehende Daten bleiben unverändert nutzbar — die neue Spalte wird beim ersten 07:00-Run automatisch befüllt. Wenn du eine eigene Kopie der xlsx pflegst: entweder die mitgelieferte Datei austauschen, oder manuell die Spalte „Capture-Code" als 16. Spalte in Inbox und 9. Spalte in Done ergänzen.
- **Cowork-Hub.xlsx, wichtige-daten.xlsx, highlights.xlsx, Bulk-Sources.md**: keine Änderungen.

---

## [1.4.0] — übernommen aus ms 1.4.0

### Neu

- **Mail-Capture-Loop** — operationaler Day-Cycle in drei Schritten:
  - **07:00 Morgen-Briefing** kommt jetzt als HTML-Mail mit `mailto:`-Links pro Task und pro Termin. Klick → Mail öffnet vorbefüllt mit Subject `DOPS-<CODE> <Titel>` und Body-Template (Status / Notiz oder Notizen / Stakeholder / Folge-Tasks).
  - **Tag über** schickt der User Status-Updates und Meeting-Notizen per Mail an sich selbst. Mail-Regel matcht auf `DOPS-` im Betreff und verschiebt nach `DOPS-Capture`-Ordner.
  - **15:30 Afternoon-Sync** liest `DOPS-Capture`, parst Captures, aktualisiert Tasks-Inbox + Kunden-MDs + Meeting-Notes, archiviert verarbeitete Mails nach `DOPS-Capture/_processed/YYYY-MM-DD/`, schickt Sync-Report-Mail.

- **Capture-Code-Schema** als robuster Identifier für Mail-Regel und Mapping:
  - `T-MMDD-NN` für Tasks (NN laufende Nummer am Tag, persistiert in Tasks-Inbox.xlsx → mehrtägig stabil)
  - `M-MMDD-XX` für Meetings (XX = Kürzel aus Termintitel, max 6 Zeichen)
  - `NEW` für Adhoc-Tasks
  - Subject-Format `DOPS-<CODE> <freitext>`

- **Neuer Scheduled Prompt** `scheduled-prompts/afternoon-sync.md` (15:30 Mo–Fr) — ergänzt das Morgen-Briefing um den Tagesabschluss-Loop.

- **Schema-Erweiterung Tasks-Inbox.xlsx**: Spalte "Capture-Code" in Inbox-Sheet (jetzt 16 Spalten) und Done-Sheet (jetzt 9 Spalten).

- **Neuer Ordner `data/Meeting-Notes/`** — Afternoon-Sync legt pro verarbeiteter Meeting-Notiz eine Datei `YYYY-MM-DD-<CODE>.md` ab, Kunden-MD bekommt einen Link unter "## Meeting-Mitschnitte".

- **Cheatsheet-Block** am Ende jeder Briefing-Mail erklärt die 4 Status-Wörter (done / progress / paused / reschedule) und das Adhoc-Mail-Format.

---

## [1.3.0] — übernommen aus ms 1.3.0

### Neu

- **Trigger-Phrasen in Description**: Description nennt jetzt explizit, bei welchen Anfragen der Skill feuern soll ("Morgen-Briefing", "Tagesüberblick", "Vorziehen vor Termin", "Kunden-Stakeholder pflegen" usw.).
- **"Wann NICHT diesen Skill nutzen"-Sektion** im SKILL.md-Body: grenzt sauber gegen built-in `daily-briefing`, `meeting-intel`, `calendar-management` und `schedule-meeting` ab.
- **Pro-Anfrage-Lade-Map** in SKILL.md: Tabelle dokumentiert welche Files für welche Anfrage gezogen werden.
- **Pfade entilden**: Alle Tilde-Pfade durch Platzhalter `<SKILL_PFAD>` ersetzt — funktioniert auch in Cloud-Containern ohne Tilde-Expansion.

---

## [1.2.0] — übernommen aus ms 1.2.0

### Neu

- **Bulk-Filter für Massenkommunikation** (`data/Bulk-Sources.md`)
  - Neue MD pflegt eine Liste bekannter Massenquellen mit drei Behandlungs-Optionen: **Ignorieren** / **Kernaussagen** / **Volltext**
  - Heuristik zur Auto-Erkennung: >20 Empfänger, DL-Absender (`noreply@*`, `*@lists.*`), typische Newsletter-Betreffe, große Gruppenchats ohne @-mention
  - Allowlist mit Vorrang: Manager-Mail und Kunden-Domains werden nie als Bulk klassifiziert
  - Auto-Archive nach `Archiv/Bulk` für klassifizierte Bulk-Mails

- **Briefing-Logik 0 — Bulk-Filtering** läuft VOR allen anderen Logiken
- **Zwei neue Briefing-Sektionen**: "Bulk-Kernaussagen" und "Neue Bulk-Quellen erkannt"

---

## [1.1.0] — übernommen aus ms 1.1.0

### Neu

- **Personen-Termin-Matching** (Logik 1)
  - Tasks-Inbox mit Spalten "Personen (Mail)", "Personen (Namen)", "Nächster gemeinsamer Termin", "Termin-Datum"
  - Cowork findet im Briefing automatisch den nächsten Termin mit Aufgaben-Personen und schlägt "Vorziehen vor Termin" vor
  - Quelle pro Task wird festgehalten: Mail-ID, Teams-Chat-Link oder Event-ID

- **Kunden-Stakeholder-Pflege** (Logik 2)
  - Cowork-Hub.xlsx Sheet "Kunden-Stakeholder" um Spalten erweitert: Entscheider-Level, Erstkontakt-Datum, Erstkontakt-Kanal, Erstkontakt-Anlass
  - Externe Personen aus Mail/Teams/Meetings werden via Mail-Domain → Kunde gemappt und automatisch in Hub + Kunden-MD eingetragen

- **Neue Briefing-Sektion "Vorziehen vor Termin"** und "Neue Kunden-Kontakte"

---

## [1.0.0] — 2026-05-01

### Initial Release

Generische Variante des Daily-Ops-Systems — abgeleitet vom internen `daily-ops-ms` (v1.2.0), ohne firmen-spezifische Begriffe und Strukturen.

**Was im Vergleich zur internen Variante anders ist:**
- Schlanker **Kunden-Sheet** (Name, Branche, Status, Letzter Kontakt, Notiz) statt Endkunden-Sheet mit Konzern-Hierarchie und Vertragsdetails
- **Interne Stakeholder** mit frei wählbaren Rollen statt fixer Rollen-Liste
- **Projekte & Milestones** statt CRM-spezifischer Opportunities-Pipeline
- **Stunden-Log** ohne externe Buchungssystem-Bezüge
- **Review-Cycles** statt firmen-spezifischer Mitarbeiter-Cycles
- Generische **Watchlist-Buzzwords** (Verlängerung, Eskalation, Beschwerde) statt firmen-interner Begriffe
- Kein Konzern-Hierarchie-Sheet
- Kein Lizenzen-Sheet (zu produktspezifisch)
- Briefing-Logik ohne hartcodierte interne Domain — wird im Scheduled-Prompt-Text konfigurierbar

**Was funktional gleich ist:**
- Personen-Termin-Matching (Logik 1)
- Kunden-Stakeholder-Pflege mit Entscheider-Level (Logik 2)
- Bulk-Filter für Massenkommunikation (Logik 0)
- Tasks-Inbox mit Quellen-Tracking
- Bulk-Sources.md
- wichtige-daten.xlsx (Personen & Anlässe + Ferien & Frei)
- Highlights-Log
- Kunden-MDs als wachsende Wissensbasis
- Scheduled Prompt für tägliches Briefing
