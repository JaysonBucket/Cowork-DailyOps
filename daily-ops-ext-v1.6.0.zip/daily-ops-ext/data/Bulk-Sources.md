# Bulk-Sources — Massenmails & Gruppenchats

Cowork pflegt diese Liste über Zeit selbst. Du kannst sie aber jederzeit anpassen.

## Wie das funktioniert

Beim Morgen-Briefing identifiziert Cowork Mails/Teams-Nachrichten, die nach Massenkommunikation aussehen (siehe Heuristiken unten). Treffer werden gegen diese Liste abgeglichen:

- **Behandlung "Kernaussagen"** → im Briefing nur 1–2 Sätze, was relevant ist. Volltext nur auf Rückfrage. Mail wird nach Briefing in den Ordner `Archiv/Bulk` verschoben.
- **Behandlung "Volltext"** → wie normale Mail behandeln (Ausnahme von der Regel, z. B. Manager-Updates die wichtig sind)
- **Behandlung "Ignorieren"** → gar nicht im Briefing erwähnen, direkt archivieren

Neue Quellen, die noch nicht in der Liste stehen, schlägt Cowork im Briefing unter "Neue Bulk-Quellen erkannt" zur Bestätigung vor — du gibst ihnen eine Behandlung.

## Heuristiken zur Erkennung

Cowork flaggt eine Mail/Nachricht als Bulk-Kandidat, wenn **mindestens zwei** zutreffen:

- > 20 Empfänger im To/CC
- Absender ist Distribution List (`*@lists.*`, `*-dl@*`, `noreply@*`, `donotreply@*`, `news@*`, `digest@*`)
- Betreff enthält: "Newsletter", "Weekly", "Daily", "Digest", "[FYI]", "Update —", "Announcement", "Reminder:", "Heads up:", "Survey", "Webinar"
- HTML-Mail mit Banner-Bild und/oder Unsubscribe-Link
- Teams-Gruppenchat mit > 15 Teilnehmern und du bist nicht direkt @-erwähnt
- Keine direkte Anrede an dich (kein "Hi {{Vorname}}", kein "@{{Vorname}}")

---

## Quellen-Liste

| Typ | Pattern (Absender / Domain / Betreff / Chat-Name) | Behandlung | Begründung | Erstellt am |
|-----|---------------------------------------------------|------------|------------|-------------|
| Absender | _(Beispiel)_ `noreply@firma.de` | Ignorieren | System-Notifications | _(Datum)_ |
| Domain | _(Beispiel)_ `*@lists.firma.de` | Kernaussagen | Distribution Lists — meist FYI | _(Datum)_ |
| Betreff | _(Beispiel)_ `Weekly Digest*` | Kernaussagen | Newsletter — selten Action nötig | _(Datum)_ |
| Chat | _(Beispiel)_ `Team All-Hands` | Kernaussagen | Großer Channel, nur bei @mention relevant | _(Datum)_ |

---

## Ausnahmen / Allowlist

Wer/Was hier steht, wird NIE als Bulk behandelt — auch wenn die Heuristiken zutreffen.

| Pattern | Grund |
|---------|-------|
| _(Beispiel)_ Manager-Mail-Adresse | Auch in DL-Mails: immer Volltext |
| _(Beispiel)_ Kunden-Domain | Externe Mails nie als Bulk archivieren |

---

## Archiv-Ziel

Standard: Outlook-Ordner `Archiv/Bulk` (wird automatisch angelegt, wenn nicht vorhanden).

Anpassbar im Scheduled-Prompt-Text — Zielordner ändern, falls du eine andere Struktur nutzt.

---

## Wartung

- **Wöchentlich** schlägt Cowork unter "Neue Bulk-Quellen erkannt" vor, was diese Woche dazukam
- **Quartalsweise** prüfen, ob Behandlungen noch passen (was früher "Kernaussagen" war, kann inzwischen "Ignorieren" sein)
- Wenn dich eine archivierte Bulk-Mail nervt ("die hätte ich gern gesehen"), Behandlung in der Tabelle auf "Volltext" setzen
