# {{Kundenname}}

**Branche:** {{Branche}}
**Status:** {{aktiv / pausiert / beendet}}

---

## Personen / Stakeholder

_Wächst über Zeit. Cowork ergänzt neue Kontakte aus Mail/Teams/Meetings automatisch (mit Lücken-Markierung). Du füllst Rolle und Entscheider-Level nach._

| Name | Rolle | Entscheider-Level | Mail | Erstkontakt | Anlass | Notiz |
|------|-------|-------------------|------|-------------|--------|-------|
| _(noch leer — wird mit erstem Kontakt befüllt)_ | | | | | | |

---

## Stand der Dinge

_Aktueller Status oben, älteres fließt nach unten. Cowork pflegt nach Status-Briefen._

- _(noch leer — wird mit erstem Status-Brief befüllt)_

---

## Verlauf / Historie

_Chronologisch absteigend. Wichtige Ereignisse, Entscheidungen, Eskalationen._

- _(noch leer)_

---

## Meeting-Mitschnitte

_Cowork hängt Recaps nach jedem Termin an._

- _(noch leer)_

---

## Dokumenten-Index

_Links auf Cloud-Storage, externe Quellen._

- _(noch leer)_

---

## Offene Punkte (qualitativ)

_Was nicht in Tasks-Inbox passt, aber im Kopf bleiben muss._

- _(noch leer)_

---

## Cowork-Pflichten

- Bei Status-Brief: Kunden-Sheet auf veraltete '?' prüfen
- Quartalsweise: Stakeholder-Aktualität prüfen
- Vor wichtigen Vertragsterminen: Vorlauf-Task in Inbox
